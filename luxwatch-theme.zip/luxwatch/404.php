<?php
/**
 * LuxWatch – 404.php
 */
get_header();
?>
<div style="min-height:100vh;background:var(--black);display:flex;align-items:center;justify-content:center;text-align:center;padding:2rem;">
    <div data-animate>
        <div style="font-family:var(--font-serif);font-size:clamp(6rem,15vw,12rem);font-weight:300;color:rgba(201,168,76,0.12);line-height:1;margin-bottom:1rem;">404</div>
        <div class="gold-divider"></div>
        <h1 style="font-size:clamp(1.8rem,4vw,2.8rem);margin:1.5rem 0 1rem;">Page Not Found</h1>
        <p style="max-width:440px;margin:0 auto 2.5rem;font-size:0.9rem;color:var(--grey-light);line-height:1.8;">The page you are looking for may have been moved or no longer exists.</p>
        <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-gold">Return Home</a>
            <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-outline">Browse Collection</a>
        </div>
    </div>
</div>
<?php get_footer(); ?>
