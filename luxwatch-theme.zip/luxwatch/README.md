# LuxWatch – WordPress Luxury Watch eCommerce Theme

## Quick Installation
1. Upload the `luxwatch` folder to `/wp-content/themes/`
2. Activate via **Appearance → Themes** in WordPress Admin
3. Pages are auto-created on activation
4. Go to **Settings → Reading** → set Homepage to the "Home" static page
5. Visit your site — done!

## Pages Included
- Home (front-page.php) — Hero, categories, featured watches, testimonials
- About Us (page-about.php) — Story, mission, values, team, timeline  
- Products (page-products.php) — Filterable grid of all 10 watches
- Single Product (page-product.php) — Gallery, specs, add to cart (?pid=1-10)
- Cart (page-cart.php) — Session cart with item removal
- Checkout (page-checkout.php) — Billing form + success modal
- Contact (page-contact.php) — Validated form with wp_mail() delivery

## Requirements: WordPress 6.0+, PHP 7.4+
