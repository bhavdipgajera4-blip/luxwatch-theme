/**
 * LuxWatch Theme — Main JavaScript
 * Handles: Header scroll, mobile nav, cart (AJAX), animations,
 *          quantity controls, checkout, contact form, toast notifications
 */

(function () {
  'use strict';

  /* =========================================================
     HEADER — scroll behaviour
     ========================================================= */
  const header = document.getElementById('site-header');
  if (header) {
    const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 60);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* =========================================================
     MOBILE NAV
     ========================================================= */
  const hamburger  = document.querySelector('.hamburger');
  const mobileNav  = document.querySelector('.mobile-nav');

  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('open');
      mobileNav.classList.toggle('open');
      document.body.style.overflow = mobileNav.classList.contains('open') ? 'hidden' : '';
    });

    mobileNav.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        hamburger.classList.remove('open');
        mobileNav.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }

  /* =========================================================
     SCROLL-TRIGGERED ANIMATIONS
     ========================================================= */
  const animEls = document.querySelectorAll('[data-animate]');
  if (animEls.length && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, i) => {
          if (entry.isIntersecting) {
            const delay = entry.target.dataset.delay || 0;
            setTimeout(() => entry.target.classList.add('visible'), parseInt(delay));
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );
    animEls.forEach(el => observer.observe(el));
  } else {
    animEls.forEach(el => el.classList.add('visible'));
  }

  /* =========================================================
     TOAST NOTIFICATIONS
     ========================================================= */
  function showToast(title, message, duration = 3500) {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M20 6L9 17l-5-5"/>
      </svg>
      <div class="toast-text">
        <div class="toast-title">${title}</div>
        ${message ? `<div class="toast-msg">${message}</div>` : ''}
      </div>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('removing');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  /* =========================================================
     CART BADGE — update from PHP session via AJAX
     ========================================================= */
  function updateCartBadge(count) {
    const badges = document.querySelectorAll('.cart-badge');
    badges.forEach(b => {
      b.textContent = count;
      b.style.display = count > 0 ? 'flex' : 'none';
    });
  }

  function fetchCartCount() {
    if (typeof luxwatch === 'undefined') return;
    fetch(luxwatch.ajax_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=lw_get_cart_count&nonce=' + luxwatch.nonce,
    })
      .then(r => r.json())
      .then(data => { if (data.success) updateCartBadge(data.data.count); })
      .catch(() => {});
  }
  fetchCartCount();

  /* =========================================================
     ADD TO CART — quick-add buttons (product grid)
     ========================================================= */
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.product-quick-add, .add-to-cart-btn');
    if (!btn) return;
    e.preventDefault();

    const productId  = btn.dataset.id;
    const productName = btn.dataset.name || 'Watch';
    if (!productId || typeof luxwatch === 'undefined') return;

    const qtyInput = document.querySelector('.qty-input');
    const qty      = qtyInput ? parseInt(qtyInput.value) || 1 : 1;

    btn.disabled = true;
    const originalText = btn.textContent;
    btn.textContent = 'Adding…';

    fetch(luxwatch.ajax_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `action=lw_add_to_cart&product_id=${productId}&qty=${qty}&nonce=${luxwatch.nonce}`,
    })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          updateCartBadge(data.data.cart_count);
          showToast('Added to Cart', productName + ' has been added to your cart.');
        } else {
          showToast('Error', data.data.message || 'Could not add item.', 4000);
        }
      })
      .catch(() => showToast('Error', 'Network error, please try again.', 4000))
      .finally(() => {
        btn.disabled = false;
        btn.textContent = originalText;
      });
  });

  /* =========================================================
     REMOVE FROM CART
     ========================================================= */
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.cart-remove-btn');
    if (!btn || typeof luxwatch === 'undefined') return;
    e.preventDefault();

    const productId = btn.dataset.id;
    const row       = btn.closest('.cart-row');

    fetch(luxwatch.ajax_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `action=lw_remove_from_cart&product_id=${productId}&nonce=${luxwatch.nonce}`,
    })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          if (row) row.style.opacity = '0';
          setTimeout(() => {
            if (row) row.remove();
            // Update totals
            const priceEl = document.querySelector('.summary-total-value');
            if (priceEl) priceEl.textContent = '$' + data.data.total.toLocaleString('en-US', { minimumFractionDigits: 2 });
            updateCartBadge(data.data.cart_count);
            // If cart empty, reload to show empty state
            if (data.data.cart_count === 0) location.reload();
          }, 350);
        }
      })
      .catch(() => {});
  });

  /* =========================================================
     QUANTITY CONTROLS (single product page)
     ========================================================= */
  const qtyInc  = document.querySelector('.qty-inc');
  const qtyDec  = document.querySelector('.qty-dec');
  const qtyInpt = document.querySelector('.qty-input');

  if (qtyInc && qtyDec && qtyInpt) {
    qtyInc.addEventListener('click', () => {
      qtyInpt.value = Math.min(parseInt(qtyInpt.value || 1) + 1, 10);
    });
    qtyDec.addEventListener('click', () => {
      qtyInpt.value = Math.max(parseInt(qtyInpt.value || 1) - 1, 1);
    });
    qtyInpt.addEventListener('change', () => {
      let v = parseInt(qtyInpt.value);
      if (isNaN(v) || v < 1) v = 1;
      if (v > 10) v = 10;
      qtyInpt.value = v;
    });
  }

  /* =========================================================
     PRODUCT IMAGE GALLERY (single product)
     ========================================================= */
  const thumbs   = document.querySelectorAll('.thumb-item');
  const mainImg  = document.querySelector('.main-image-wrap img');

  thumbs.forEach(thumb => {
    thumb.addEventListener('click', () => {
      thumbs.forEach(t => t.classList.remove('active'));
      thumb.classList.add('active');
      if (mainImg) {
        mainImg.style.opacity = '0';
        mainImg.style.transform = 'scale(0.97)';
        setTimeout(() => {
          mainImg.src = thumb.querySelector('img').src;
          mainImg.style.opacity = '1';
          mainImg.style.transform = 'scale(1)';
        }, 220);
      }
    });
  });
  if (mainImg) { mainImg.style.transition = 'opacity 0.22s ease, transform 0.22s ease'; }

  /* =========================================================
     PRODUCT FILTER (products page)
     ========================================================= */
  const filterBtns  = document.querySelectorAll('.filter-btn');
  const productCards = document.querySelectorAll('.product-card[data-category]');
  const countEl     = document.querySelector('.products-count');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const cat = btn.dataset.filter;
      let visible = 0;

      productCards.forEach(card => {
        const match = cat === 'all' || card.dataset.category === cat;
        card.style.opacity   = match ? '' : '0';
        card.style.transform = match ? '' : 'scale(0.95)';
        card.style.display   = match ? '' : 'none';
        if (match) visible++;
      });

      setTimeout(() => {
        productCards.forEach(card => {
          if (card.style.display !== 'none') {
            card.style.opacity = '1';
            card.style.transform = '';
          }
        });
      }, 20);

      if (countEl) countEl.textContent = `Showing ${visible} timepiece${visible !== 1 ? 's' : ''}`;
    });
  });

  /* =========================================================
     CHECKOUT — Place Order
     ========================================================= */
  const placeOrderBtn = document.querySelector('.place-order-btn');
  const successOverlay = document.querySelector('.success-overlay');
  const successClose   = document.querySelector('.success-close-btn');
  const checkoutForm   = document.querySelector('#checkout-form');

  if (placeOrderBtn && checkoutForm) {
    placeOrderBtn.addEventListener('click', function (e) {
      e.preventDefault();
      if (!validateCheckoutForm()) return;

      placeOrderBtn.disabled = true;
      placeOrderBtn.textContent = 'Processing…';

      const formData = new FormData(checkoutForm);
      formData.append('action', 'lw_place_order');
      formData.append('nonce', luxwatch ? luxwatch.nonce : '');

      fetch(luxwatch.ajax_url, {
        method: 'POST',
        body: new URLSearchParams(formData),
      })
        .then(r => r.json())
        .then(data => {
          if (data.success) {
            if (successOverlay) {
              const orderNum = document.querySelector('.order-number-display');
              if (orderNum) orderNum.textContent = data.data.order_number;
              successOverlay.classList.add('show');
            }
            updateCartBadge(0);
          } else {
            showToast('Error', data.data.message || 'Could not place order.', 5000);
            placeOrderBtn.disabled = false;
            placeOrderBtn.textContent = 'Place Order';
          }
        })
        .catch(() => {
          showToast('Error', 'Network error. Please try again.', 5000);
          placeOrderBtn.disabled = false;
          placeOrderBtn.textContent = 'Place Order';
        });
    });
  }

  if (successOverlay) {
    successOverlay.addEventListener('click', function (e) {
      if (e.target === successOverlay) closeSuccess();
    });
  }
  if (successClose) successClose.addEventListener('click', closeSuccess);

  function closeSuccess() {
    if (successOverlay) successOverlay.classList.remove('show');
    if (typeof luxwatch !== 'undefined' && luxwatch.home_url) {
      window.location.href = luxwatch.home_url;
    }
  }

  /* =========================================================
     CHECKOUT FORM VALIDATION
     ========================================================= */
  function validateCheckoutForm() {
    let valid = true;
    const requiredFields = checkoutForm.querySelectorAll('[required]');

    requiredFields.forEach(field => {
      const error = field.parentElement.querySelector('.form-error');
      const val   = field.value.trim();

      if (!val) {
        valid = false;
        field.style.borderColor = '#e53e3e';
        if (error) { error.textContent = 'This field is required.'; error.classList.add('show'); }
      } else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
        valid = false;
        field.style.borderColor = '#e53e3e';
        if (error) { error.textContent = 'Please enter a valid email.'; error.classList.add('show'); }
      } else {
        field.style.borderColor = '';
        if (error) error.classList.remove('show');
      }
    });

    return valid;
  }

  if (checkoutForm) {
    checkoutForm.querySelectorAll('[required]').forEach(field => {
      field.addEventListener('input', () => {
        field.style.borderColor = '';
        const error = field.parentElement.querySelector('.form-error');
        if (error) error.classList.remove('show');
      });
    });
  }

  /* =========================================================
     CONTACT FORM
     ========================================================= */
  const contactForm = document.querySelector('#contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!validateContactForm()) return;

      const submitBtn = contactForm.querySelector('[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Sending…';

      const formData = new FormData(contactForm);
      formData.append('action', 'lw_contact_form');
      formData.append('nonce', luxwatch ? luxwatch.nonce : '');

      fetch(luxwatch.ajax_url, {
        method: 'POST',
        body: new URLSearchParams(formData),
      })
        .then(r => r.json())
        .then(data => {
          if (data.success) {
            contactForm.style.display = 'none';
            const successEl = document.querySelector('.contact-success');
            if (successEl) successEl.classList.add('show');
          } else {
            showToast('Error', data.data.message || 'Could not send message.', 5000);
            submitBtn.disabled = false;
            submitBtn.textContent = 'Send Message';
          }
        })
        .catch(() => {
          showToast('Error', 'Network error. Please try again.', 5000);
          submitBtn.disabled = false;
          submitBtn.textContent = 'Send Message';
        });
    });
  }

  function validateContactForm() {
    let valid = true;
    contactForm.querySelectorAll('[required]').forEach(field => {
      const error = field.parentElement.querySelector('.form-error');
      const val   = field.value.trim();

      if (!val) {
        valid = false;
        field.style.borderColor = '#e53e3e';
        if (error) { error.textContent = 'Required.'; error.classList.add('show'); }
      } else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
        valid = false;
        field.style.borderColor = '#e53e3e';
        if (error) { error.textContent = 'Invalid email.'; error.classList.add('show'); }
      } else {
        field.style.borderColor = '';
        if (error) error.classList.remove('show');
      }
    });
    return valid;
  }

  if (contactForm) {
    contactForm.querySelectorAll('[required]').forEach(field => {
      field.addEventListener('input', () => {
        field.style.borderColor = '';
        const error = field.parentElement.querySelector('.form-error');
        if (error) error.classList.remove('show');
      });
    });
  }

  /* =========================================================
     ACTIVE NAV LINK
     ========================================================= */
  const currentPath = window.location.pathname;
  document.querySelectorAll('.main-nav a, .mobile-nav a').forEach(link => {
    if (link.getAttribute('href') === currentPath ||
        (link.getAttribute('href') !== '/' && currentPath.startsWith(link.getAttribute('href')))) {
      link.classList.add('active');
    }
  });

})();
