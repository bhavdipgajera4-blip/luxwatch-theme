<!-- ======================================================
     SITE FOOTER
     ====================================================== -->
<footer id="site-footer">
    <div class="container">

        <!-- Footer Main Grid -->
        <div class="footer-main">

            <!-- Brand Column -->
            <div class="footer-brand">
                <div class="footer-logo">
                    <?php echo esc_html( get_theme_mod( 'lw_brand_name', 'LuxWatch' ) ); ?><span class="dot" style="color:var(--gold)">.</span>
                </div>
                <div class="footer-tagline">Swiss Timepieces Since 1887</div>
                <p class="footer-about-text">
                    Crafting exceptional timepieces for those who appreciate the artistry of horology. Each watch is a testament to our unwavering dedication to precision and beauty.
                </p>

                <!-- Social Links -->
                <div class="social-links">
                    <!-- Instagram -->
                    <a href="#" class="social-link" aria-label="Instagram">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
                            <circle cx="12" cy="12" r="4"/>
                            <circle cx="17.5" cy="6.5" r="0.5" fill="currentColor"/>
                        </svg>
                    </a>
                    <!-- Facebook -->
                    <a href="#" class="social-link" aria-label="Facebook">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/>
                        </svg>
                    </a>
                    <!-- Twitter / X -->
                    <a href="#" class="social-link" aria-label="Twitter">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"/>
                        </svg>
                    </a>
                    <!-- YouTube -->
                    <a href="#" class="social-link" aria-label="YouTube">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 00-1.95 1.96A29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 001.95-1.95A29 29 0 0023 12a29 29 0 00-.46-5.58z"/>
                            <polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" stroke-width="1.5"/>
                        </svg>
                    </a>
                </div>
            </div>

            <!-- Collections Column -->
            <div class="footer-col">
                <h4>Collections</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url( home_url( '/products' ) ); ?>">All Watches</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/products' ) ); ?>">Dress Watches</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/products' ) ); ?>">Dive Watches</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/products' ) ); ?>">Pilot Watches</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/products' ) ); ?>">Sport Watches</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/products' ) ); ?>">Limited Editions</a></li>
                </ul>
            </div>

            <!-- Company Column -->
            <div class="footer-col">
                <h4>Company</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About Us</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">Our Heritage</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">Craftsmanship</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">Press</a></li>
                </ul>
            </div>

            <!-- Contact Column -->
            <div class="footer-col">
                <h4>Get In Touch</h4>

                <div class="footer-contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/>
                        <circle cx="12" cy="10" r="3"/>
                    </svg>
                    <span>12 Rue de la Paix<br>Geneva, Switzerland</span>
                </div>

                <div class="footer-contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013 8.77a19.79 19.79 0 01-3.07-8.67A2 2 0 011.92 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"/>
                    </svg>
                    <span>+41 22 000 0000</span>
                </div>

                <div class="footer-contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                        <polyline points="22,6 12,13 2,6"/>
                    </svg>
                    <span>boutique@luxwatch.com</span>
                </div>

                <div class="footer-contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="12 6 12 12 16 14"/>
                    </svg>
                    <span>Mon – Sat: 9am – 7pm<br>Sunday: Closed</span>
                </div>
            </div>

        </div><!-- .footer-main -->

        <!-- Footer Bottom Bar -->
        <div class="footer-bottom">
            <p>
                &copy; <?php echo esc_html( gmdate( 'Y' ) ); ?>
                <?php echo esc_html( get_theme_mod( 'lw_brand_name', 'LuxWatch' ) ); ?>.
                All rights reserved. &mdash;
                <a href="#">Privacy Policy</a> &bull;
                <a href="#">Terms of Service</a>
            </p>
            <p>Crafted with passion &amp; precision in Switzerland.</p>
        </div>

    </div><!-- .container -->
</footer>

<?php wp_footer(); ?>
</body>
</html>
