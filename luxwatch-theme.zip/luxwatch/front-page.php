<?php
/**
 * Template Name: Home
 * Front page — Hero, Categories, Featured Watches, Story, Testimonials.
 */
get_header();
$products = lw_get_products();
?>

<!-- ======================================================
     HERO SECTION
     ====================================================== -->
<section class="hero">
    <div class="hero-bg"></div>
    <div class="hero-bg-img"></div>
    <div class="hero-grid-lines"></div>

    <div class="container">
        <div class="hero-content">

            <div class="hero-eyebrow">
                <span><?php echo esc_html( get_theme_mod( 'lw_hero_eyebrow', 'Established Since 1887' ) ); ?></span>
            </div>

            <h1>
                <?php echo esc_html( get_theme_mod( 'lw_hero_title_1', 'The Art of' ) ); ?><br>
                <em><?php echo esc_html( get_theme_mod( 'lw_hero_title_2', 'Timeless Precision' ) ); ?></em>
            </h1>

            <p class="hero-description">
                Discover masterpieces born from centuries of Swiss horological tradition. Each timepiece is a fusion of mechanical artistry, rare materials, and uncompromising craftsmanship.
            </p>

            <div class="hero-actions">
                <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-gold">
                    Explore Collection
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
                        <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
                    </svg>
                </a>
                <a href="<?php echo esc_url( home_url( '/about' ) ); ?>" class="btn btn-outline">Our Heritage</a>
            </div>

            <div class="hero-stats">
                <div class="stat-item">
                    <div class="stat-num">137</div>
                    <div class="stat-label">Years of Craft</div>
                </div>
                <div class="stat-item">
                    <div class="stat-num">42k+</div>
                    <div class="stat-label">Watches Sold</div>
                </div>
                <div class="stat-item">
                    <div class="stat-num">98%</div>
                    <div class="stat-label">Client Satisfaction</div>
                </div>
            </div>

        </div>
    </div><!-- .container -->

    <div class="hero-scroll">
        <span>Scroll</span>
        <div class="scroll-line"></div>
    </div>
</section>

<!-- ======================================================
     MARQUEE BRAND STRIP
     ====================================================== -->
<div class="marquee-section">
    <div class="marquee-track">
        <?php
        $brands = [ 'Precision Engineering', 'Swiss Made', 'Sapphire Crystal', 'In-House Movement', 'Hand Assembled', 'Limited Editions', 'Luxury Timepieces', 'Since 1887', 'Precision Engineering', 'Swiss Made', 'Sapphire Crystal', 'In-House Movement', 'Hand Assembled', 'Limited Editions', 'Luxury Timepieces', 'Since 1887' ];
        foreach ( $brands as $i => $brand ) : ?>
            <div class="marquee-item">
                <?php echo esc_html( $brand ); ?>
                <?php if ( $i < count( $brands ) - 1 ) : ?>
                    <span class="marquee-sep">◆</span>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- ======================================================
     WATCH CATEGORIES
     ====================================================== -->
<section class="categories-section section-pad">
    <div class="container">
        <div class="text-center" style="margin-bottom:4rem;" data-animate>
            <span class="section-label">Browse by Style</span>
            <h2 class="section-title">Our Collections</h2>
            <div class="gold-divider"></div>
        </div>
    </div>

    <div class="categories-grid">
        <?php
        $categories = [
            [ 'name' => 'Dress Watches',   'sub' => 'Elegance & Formality',   'slug' => 'dress',  'img' => 'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80' ],
            [ 'name' => 'Dive Watches',    'sub' => 'Depth & Adventure',      'slug' => 'diver',  'img' => 'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80' ],
            [ 'name' => 'Pilot Watches',   'sub' => 'Precision & Altitude',   'slug' => 'pilot',  'img' => 'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80' ],
            [ 'name' => 'Sport Watches',   'sub' => 'Performance & Speed',    'slug' => 'sport',  'img' => 'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80' ],
        ];
        foreach ( $categories as $cat ) : ?>
            <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="category-card">
                <img src="<?php echo esc_url( $cat['img'] ); ?>" alt="<?php echo esc_attr( $cat['name'] ); ?>" class="category-img" loading="lazy">
                <div class="category-overlay">
                    <span><?php echo esc_html( $cat['sub'] ); ?></span>
                    <h3><?php echo esc_html( $cat['name'] ); ?></h3>
                    <div class="category-arrow">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
                        </svg>
                    </div>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<!-- ======================================================
     FEATURED WATCHES
     ====================================================== -->
<section class="featured-section section-pad">
    <div class="container">

        <div class="section-header" data-animate>
            <div>
                <span class="section-label">Curated Selection</span>
                <h2 class="section-title">Featured Timepieces</h2>
            </div>
            <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-outline">
                View All
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12">
                    <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
                </svg>
            </a>
        </div>

        <div class="watches-grid">
            <?php foreach ( array_slice( $products, 0, 6 ) as $i => $p ) : ?>
            <div class="product-card" data-animate data-delay="<?php echo $i * 80; ?>">
                <?php if ( $p['badge'] ) : ?>
                    <span class="product-badge"><?php echo esc_html( $p['badge'] ); ?></span>
                <?php endif; ?>

                <div class="product-img-wrap">
                    <img
                        src="<?php echo esc_url( $p['image'] ); ?>"
                        alt="<?php echo esc_attr( $p['name'] ); ?>"
                        class="product-img"
                        loading="lazy"
                    >
                    <button
                        class="product-quick-add"
                        data-id="<?php echo esc_attr( $p['id'] ); ?>"
                        data-name="<?php echo esc_attr( $p['name'] ); ?>"
                    >Add to Cart</button>
                </div>

                <div class="product-info">
                    <div class="product-brand"><?php echo esc_html( $p['brand'] ); ?></div>
                    <h3 class="product-name">
                        <a href="<?php echo esc_url( home_url( '/product/?pid=' . $p['id'] ) ); ?>">
                            <?php echo esc_html( $p['name'] ); ?>
                        </a>
                    </h3>
                    <p class="product-desc"><?php echo esc_html( substr( $p['description'], 0, 80 ) . '…' ); ?></p>
                    <div class="product-footer">
                        <span class="product-price">
                            <span class="currency">$</span><?php echo number_format( $p['price'] ); ?>
                        </span>
                        <?php echo lw_stars( $p['rating'] ); ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    </div><!-- .container -->
</section>

<!-- ======================================================
     BRAND STORY STRIP
     ====================================================== -->
<section class="story-section">
    <div class="story-inner">
        <div class="story-img-side">
            <img
                src="https://images.unsplash.com/photo-1539874754764-5a96559165b0?w=900&q=80"
                alt="Watchmaker at work"
                loading="lazy"
            >
            <div class="story-img-overlay"></div>
        </div>

        <div class="story-content-side" data-animate>
            <span class="section-label">Our Story</span>
            <h2 class="section-title">A Legacy Forged in Swiss Precision</h2>

            <blockquote class="story-quote">
                "Every second hand movement is a heartbeat of precision — a silent promise kept across generations."
            </blockquote>

            <p class="section-subtitle" style="margin-bottom:2rem;">
                Since 1887, LuxWatch has been crafting exceptional timepieces in the ateliers of Geneva. Each watch passes through the hands of 47 master craftsmen before reaching your wrist.
            </p>

            <a href="<?php echo esc_url( home_url( '/about' ) ); ?>" class="btn btn-gold">
                Discover Our Heritage
            </a>
        </div>
    </div>
</section>

<!-- ======================================================
     TESTIMONIALS
     ====================================================== -->
<section class="testimonials-section section-pad">
    <div class="container">

        <div class="text-center" style="margin-bottom:4rem;" data-animate>
            <span class="section-label">Client Stories</span>
            <h2 class="section-title">Words from our Patrons</h2>
            <div class="gold-divider"></div>
        </div>

        <div class="testimonials-grid">
            <?php
            $testimonials = [
                [
                    'text'   => 'The Royal Perpetual I purchased three years ago has exceeded every expectation. The movement is extraordinarily accurate, and the dial still commands admiration wherever I wear it.',
                    'name'   => 'James Harrington',
                    'title'  => 'Private Equity Director, London',
                    'rating' => 5,
                    'initial'=> 'J',
                ],
                [
                    'text'   => 'I acquired the Grand Tourbillon as a 50th birthday gift to myself. The experience from first enquiry to delivery was impeccable — as refined as the watch itself.',
                    'name'   => 'Sophie Leblanc',
                    'title'  => 'Architect, Paris',
                    'rating' => 5,
                    'initial'=> 'S',
                ],
                [
                    'text'   => 'Three LuxWatch timepieces now reside in my collection. The craftsmanship is unparalleled, and the after-sales service sets a benchmark that no other boutique has matched.',
                    'name'   => 'Rajan Mehta',
                    'title'  => 'Collector, Dubai',
                    'rating' => 5,
                    'initial'=> 'R',
                ],
            ];
            foreach ( $testimonials as $i => $t ) : ?>
            <div class="testimonial-card" data-animate data-delay="<?php echo $i * 100; ?>">
                <div class="testimonial-stars">
                    <?php for ( $s = 0; $s < $t['rating']; $s++ ) echo '<span class="star">★</span>'; ?>
                </div>
                <p class="testimonial-text"><?php echo esc_html( $t['text'] ); ?></p>
                <div class="testimonial-author">
                    <div class="author-avatar"><?php echo esc_html( $t['initial'] ); ?></div>
                    <div>
                        <div class="author-name"><?php echo esc_html( $t['name'] ); ?></div>
                        <div class="author-title"><?php echo esc_html( $t['title'] ); ?></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    </div><!-- .container -->
</section>

<!-- ======================================================
     CTA BAND
     ====================================================== -->
<section style="background:linear-gradient(135deg,#0f0f0f 0%,#1a1400 50%,#0f0f0f 100%); padding:5rem 0; border-top:1px solid rgba(201,168,76,0.15); border-bottom:1px solid rgba(201,168,76,0.15);">
    <div class="container text-center" data-animate>
        <span class="section-label">Boutique Experience</span>
        <h2 class="section-title">Visit Us in Geneva</h2>
        <div class="gold-divider"></div>
        <p class="section-subtitle" style="margin:0 auto 2.5rem;">
            Experience our full collection in person at our flagship boutique. Our expert horologists are available for private viewings and bespoke consultations.
        </p>
        <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;">
            <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="btn btn-gold">Book a Consultation</a>
            <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-outline">Browse Online</a>
        </div>
    </div>
</section>

<?php get_footer(); ?>
