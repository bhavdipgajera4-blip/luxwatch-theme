<?php
/**
 * LuxWatch Theme – functions.php
 * Theme setup, asset enqueueing, AJAX handlers, and helpers.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ---------------------------------------------------------------
   Load Includes
--------------------------------------------------------------- */
require_once get_template_directory() . '/inc/products.php';
require_once get_template_directory() . '/inc/cart-functions.php';

/* ---------------------------------------------------------------
   Theme Setup
--------------------------------------------------------------- */
function lw_theme_setup() {
    // WordPress features
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'gallery', 'caption' ] );
    add_theme_support( 'custom-logo', [
        'height'      => 80,
        'width'       => 200,
        'flex-width'  => true,
        'flex-height' => true,
    ] );
    add_theme_support( 'automatic-feed-links' );

    // Navigation menus
    register_nav_menus( [
        'primary' => __( 'Primary Navigation', 'luxwatch' ),
        'footer'  => __( 'Footer Navigation',  'luxwatch' ),
    ] );
}
add_action( 'after_setup_theme', 'lw_theme_setup' );

/* ---------------------------------------------------------------
   Enqueue Scripts & Styles
--------------------------------------------------------------- */
function lw_enqueue_assets() {
    $ver = '1.0.0';

    // Main stylesheet
    wp_enqueue_style(
        'luxwatch-style',
        get_template_directory_uri() . '/assets/css/style.css',
        [],
        $ver
    );

    // Main JS
    wp_enqueue_script(
        'luxwatch-main',
        get_template_directory_uri() . '/assets/js/main.js',
        [],
        $ver,
        true   // load in footer
    );

    // Pass data to JS
    wp_localize_script( 'luxwatch-main', 'luxwatch', [
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'lw_nonce' ),
        'home_url' => home_url( '/' ),
        'cart_url' => lw_page_url( 'cart' ),
    ] );
}
add_action( 'wp_enqueue_scripts', 'lw_enqueue_assets' );

/* ---------------------------------------------------------------
   Helper: Get Page URL by template slug
--------------------------------------------------------------- */
function lw_page_url( $template_slug ) {
    $page = lw_get_page_by_template( $template_slug );
    return $page ? get_permalink( $page->ID ) : home_url( '/' );
}

function lw_get_page_by_template( $slug ) {
    $pages = get_pages( [
        'meta_key'   => '_wp_page_template',
        'meta_value' => 'page-' . $slug . '.php',
    ] );
    return $pages ? $pages[0] : null;
}

/* ---------------------------------------------------------------
   Register Widget Areas (Sidebars)
--------------------------------------------------------------- */
function lw_register_sidebars() {
    register_sidebar( [
        'name'          => __( 'Footer Widget Area', 'luxwatch' ),
        'id'            => 'footer-widgets',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ] );
}
add_action( 'widgets_init', 'lw_register_sidebars' );

/* ---------------------------------------------------------------
   Customizer Options
--------------------------------------------------------------- */
function lw_customizer( $wp_customize ) {
    // Brand Name
    $wp_customize->add_setting( 'lw_brand_name', [
        'default'   => 'LuxWatch',
        'transport' => 'refresh',
    ] );
    $wp_customize->add_control( 'lw_brand_name', [
        'label'   => __( 'Brand Name', 'luxwatch' ),
        'section' => 'title_tagline',
        'type'    => 'text',
    ] );

    // Hero Tagline
    $wp_customize->add_section( 'lw_hero', [
        'title'    => __( 'Hero Section', 'luxwatch' ),
        'priority' => 30,
    ] );
    $wp_customize->add_setting( 'lw_hero_eyebrow', [
        'default'   => 'Established Since 1887',
        'transport' => 'refresh',
    ] );
    $wp_customize->add_control( 'lw_hero_eyebrow', [
        'label'   => __( 'Hero Eyebrow Text', 'luxwatch' ),
        'section' => 'lw_hero',
        'type'    => 'text',
    ] );
    $wp_customize->add_setting( 'lw_hero_title_1', [
        'default'   => 'The Art of',
        'transport' => 'refresh',
    ] );
    $wp_customize->add_control( 'lw_hero_title_1', [
        'label'   => __( 'Hero Title Line 1', 'luxwatch' ),
        'section' => 'lw_hero',
        'type'    => 'text',
    ] );
    $wp_customize->add_setting( 'lw_hero_title_2', [
        'default'   => 'Timeless Precision',
        'transport' => 'refresh',
    ] );
    $wp_customize->add_control( 'lw_hero_title_2', [
        'label'   => __( 'Hero Title Line 2 (italic)', 'luxwatch' ),
        'section' => 'lw_hero',
        'type'    => 'text',
    ] );
}
add_action( 'customize_register', 'lw_customizer' );

/* ---------------------------------------------------------------
   Page Template Assignment Helper
   (Auto-create required pages on theme activation)
--------------------------------------------------------------- */
function lw_create_default_pages() {
    $pages = [
        'home'     => [ 'title' => 'Home',     'template' => '' ],
        'about'    => [ 'title' => 'About Us',  'template' => 'page-about.php' ],
        'products' => [ 'title' => 'Products',  'template' => 'page-products.php' ],
        'cart'     => [ 'title' => 'Cart',      'template' => 'page-cart.php' ],
        'checkout' => [ 'title' => 'Checkout',  'template' => 'page-checkout.php' ],
        'contact'  => [ 'title' => 'Contact',   'template' => 'page-contact.php' ],
    ];

    foreach ( $pages as $slug => $data ) {
        // Skip if a page with this slug already exists
        if ( get_page_by_path( $slug ) ) continue;

        $page_id = wp_insert_post( [
            'post_title'  => $data['title'],
            'post_name'   => $slug,
            'post_status' => 'publish',
            'post_type'   => 'page',
        ] );

        if ( $data['template'] && ! is_wp_error( $page_id ) ) {
            update_post_meta( $page_id, '_wp_page_template', $data['template'] );
        }

        // Set the Home page as the static front page
        if ( 'home' === $slug && ! is_wp_error( $page_id ) ) {
            update_option( 'page_on_front', $page_id );
            update_option( 'show_on_front', 'page' );
        }
    }
}
add_action( 'after_switch_theme', 'lw_create_default_pages' );

/* ---------------------------------------------------------------
   Document Title Separator
--------------------------------------------------------------- */
function lw_title_separator() { return '|'; }
add_filter( 'document_title_separator', 'lw_title_separator' );

/* ---------------------------------------------------------------
   Excerpt Length
--------------------------------------------------------------- */
function lw_excerpt_length() { return 20; }
add_filter( 'excerpt_length', 'lw_excerpt_length' );

/* ---------------------------------------------------------------
   Body Classes
--------------------------------------------------------------- */
function lw_body_classes( $classes ) {
    $classes[] = 'luxwatch-theme';
    return $classes;
}
add_filter( 'body_class', 'lw_body_classes' );
