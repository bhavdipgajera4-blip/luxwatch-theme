<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ======================================================
     SITE HEADER / NAVIGATION
     ====================================================== -->
<header id="site-header">
    <div class="container">
        <div class="header-inner">

            <!-- Logo -->
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo">
                <span class="logo-main">
                    <?php echo esc_html( get_theme_mod( 'lw_brand_name', 'LuxWatch' ) ); ?><span class="logo-dot">.</span>
                </span>
                <span class="logo-sub">Swiss Timepieces</span>
            </a>

            <!-- Primary Navigation -->
            <nav class="main-nav" aria-label="Primary Navigation">
                <ul>
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/products' ) ); ?>">Collection</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a></li>
                </ul>
            </nav>

            <!-- Header Actions -->
            <div class="header-actions">
                <!-- Shop Collection CTA (desktop) -->
                <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-outline" style="display:none;">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14">
                        <circle cx="12" cy="12" r="10"/><polyline points="12 8 16 12 12 16"/><line x1="8" y1="12" x2="16" y2="12"/>
                    </svg>
                    Explore
                </a>

                <!-- Cart Icon -->
                <a href="<?php echo esc_url( home_url( '/cart' ) ); ?>" class="cart-icon-btn" aria-label="Shopping Cart">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>
                        <line x1="3" y1="6" x2="21" y2="6"/>
                        <path d="M16 10a4 4 0 01-8 0"/>
                    </svg>
                    <span class="cart-badge" style="display:<?php echo lw_cart_count() > 0 ? 'flex' : 'none'; ?>">
                        <?php echo lw_cart_count(); ?>
                    </span>
                </a>

                <!-- Hamburger (mobile) -->
                <button class="hamburger" aria-label="Toggle Menu" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>

        </div><!-- .header-inner -->
    </div><!-- .container -->
</header>

<!-- Mobile Navigation Overlay -->
<nav class="mobile-nav" aria-label="Mobile Navigation">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
    <a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About</a>
    <a href="<?php echo esc_url( home_url( '/products' ) ); ?>">Collection</a>
    <a href="<?php echo esc_url( home_url( '/cart' ) ); ?>">Cart
        <span class="cart-badge" style="position:relative;top:-2px;right:auto;display:<?php echo lw_cart_count() > 0 ? 'inline-flex' : 'none'; ?>; margin-left:8px;">
            <?php echo lw_cart_count(); ?>
        </span>
    </a>
    <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a>
</nav>

<!-- Page content starts below -->
