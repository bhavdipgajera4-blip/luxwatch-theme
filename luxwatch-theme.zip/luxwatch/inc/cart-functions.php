<?php
/**
 * LuxWatch – Cart Functions
 * Session-based cart: add, remove, clear, totals, AJAX handlers.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ---------------------------------------------------------------
   Session Bootstrap
--------------------------------------------------------------- */
function lw_start_session() {
    if ( ! session_id() && ! headers_sent() ) {
        session_start();
    }
}
add_action( 'init', 'lw_start_session', 1 );

/* ---------------------------------------------------------------
   Cart Helpers
--------------------------------------------------------------- */

/** Return cart array from session (always an array). */
function lw_get_cart() {
    return isset( $_SESSION['lw_cart'] ) ? (array) $_SESSION['lw_cart'] : [];
}

/** Save cart back to session. */
function lw_save_cart( $cart ) {
    $_SESSION['lw_cart'] = $cart;
}

/** Number of items (total qty) in cart. */
function lw_cart_count() {
    $cart  = lw_get_cart();
    $count = 0;
    foreach ( $cart as $item ) {
        $count += (int) $item['qty'];
    }
    return $count;
}

/** Calculate cart total. */
function lw_cart_total() {
    $cart  = lw_get_cart();
    $total = 0;
    foreach ( $cart as $item ) {
        $total += $item['price'] * $item['qty'];
    }
    return $total;
}

/** Add (or increase qty) of a product. */
function lw_add_item( $product_id, $qty = 1 ) {
    $product = lw_get_product( $product_id );
    if ( ! $product ) return false;

    $cart = lw_get_cart();

    if ( isset( $cart[ $product_id ] ) ) {
        $cart[ $product_id ]['qty'] += (int) $qty;
    } else {
        $cart[ $product_id ] = [
            'id'    => $product['id'],
            'name'  => $product['name'],
            'brand' => $product['brand'],
            'price' => $product['price'],
            'image' => $product['image'],
            'qty'   => (int) $qty,
        ];
    }

    lw_save_cart( $cart );
    return true;
}

/** Remove an item from the cart entirely. */
function lw_remove_item( $product_id ) {
    $cart = lw_get_cart();
    unset( $cart[ $product_id ] );
    lw_save_cart( $cart );
}

/** Clear the whole cart. */
function lw_clear_cart() {
    $_SESSION['lw_cart'] = [];
}

/* ---------------------------------------------------------------
   AJAX: Get Cart Count
--------------------------------------------------------------- */
function lw_ajax_get_cart_count() {
    check_ajax_referer( 'lw_nonce', 'nonce' );
    wp_send_json_success( [ 'count' => lw_cart_count() ] );
}
add_action( 'wp_ajax_lw_get_cart_count',        'lw_ajax_get_cart_count' );
add_action( 'wp_ajax_nopriv_lw_get_cart_count', 'lw_ajax_get_cart_count' );

/* ---------------------------------------------------------------
   AJAX: Add to Cart
--------------------------------------------------------------- */
function lw_ajax_add_to_cart() {
    check_ajax_referer( 'lw_nonce', 'nonce' );

    $product_id = absint( $_POST['product_id'] ?? 0 );
    $qty        = max( 1, absint( $_POST['qty'] ?? 1 ) );

    if ( ! $product_id ) {
        wp_send_json_error( [ 'message' => 'Invalid product.' ] );
    }

    $added = lw_add_item( $product_id, $qty );

    if ( $added ) {
        wp_send_json_success( [
            'cart_count' => lw_cart_count(),
            'cart_total' => lw_cart_total(),
        ] );
    } else {
        wp_send_json_error( [ 'message' => 'Product not found.' ] );
    }
}
add_action( 'wp_ajax_lw_add_to_cart',        'lw_ajax_add_to_cart' );
add_action( 'wp_ajax_nopriv_lw_add_to_cart', 'lw_ajax_add_to_cart' );

/* ---------------------------------------------------------------
   AJAX: Remove from Cart
--------------------------------------------------------------- */
function lw_ajax_remove_from_cart() {
    check_ajax_referer( 'lw_nonce', 'nonce' );

    $product_id = absint( $_POST['product_id'] ?? 0 );
    lw_remove_item( $product_id );

    wp_send_json_success( [
        'cart_count' => lw_cart_count(),
        'total'      => lw_cart_total(),
    ] );
}
add_action( 'wp_ajax_lw_remove_from_cart',        'lw_ajax_remove_from_cart' );
add_action( 'wp_ajax_nopriv_lw_remove_from_cart', 'lw_ajax_remove_from_cart' );

/* ---------------------------------------------------------------
   AJAX: Place Order
--------------------------------------------------------------- */
function lw_ajax_place_order() {
    check_ajax_referer( 'lw_nonce', 'nonce' );

    $cart = lw_get_cart();
    if ( empty( $cart ) ) {
        wp_send_json_error( [ 'message' => 'Your cart is empty.' ] );
    }

    // Sanitise customer fields
    $first_name = sanitize_text_field( $_POST['first_name'] ?? '' );
    $last_name  = sanitize_text_field( $_POST['last_name']  ?? '' );
    $email      = sanitize_email( $_POST['email']           ?? '' );
    $phone      = sanitize_text_field( $_POST['phone']      ?? '' );
    $address    = sanitize_text_field( $_POST['address']    ?? '' );
    $city       = sanitize_text_field( $_POST['city']       ?? '' );
    $country    = sanitize_text_field( $_POST['country']    ?? '' );

    if ( ! $first_name || ! $last_name || ! $email ) {
        wp_send_json_error( [ 'message' => 'Please fill in all required fields.' ] );
    }
    if ( ! is_email( $email ) ) {
        wp_send_json_error( [ 'message' => 'Please provide a valid email address.' ] );
    }

    // Generate a simple order number
    $order_number = 'LW-' . strtoupper( substr( md5( uniqid() ), 0, 8 ) );

    // Store order in session (could also be saved as a WP custom post type)
    $_SESSION['lw_last_order'] = [
        'order_number' => $order_number,
        'customer'     => compact( 'first_name', 'last_name', 'email', 'phone', 'address', 'city', 'country' ),
        'items'        => $cart,
        'total'        => lw_cart_total(),
        'date'         => current_time( 'mysql' ),
    ];

    // Clear the cart after placing order
    lw_clear_cart();

    wp_send_json_success( [
        'order_number' => $order_number,
        'message'      => 'Order placed successfully.',
    ] );
}
add_action( 'wp_ajax_lw_place_order',        'lw_ajax_place_order' );
add_action( 'wp_ajax_nopriv_lw_place_order', 'lw_ajax_place_order' );

/* ---------------------------------------------------------------
   AJAX: Contact Form
--------------------------------------------------------------- */
function lw_ajax_contact_form() {
    check_ajax_referer( 'lw_nonce', 'nonce' );

    $name    = sanitize_text_field( $_POST['contact_name']    ?? '' );
    $email   = sanitize_email(      $_POST['contact_email']   ?? '' );
    $subject = sanitize_text_field( $_POST['contact_subject'] ?? 'No Subject' );
    $message = sanitize_textarea_field( $_POST['contact_message'] ?? '' );

    if ( ! $name || ! $email || ! $message ) {
        wp_send_json_error( [ 'message' => 'Please fill in all required fields.' ] );
    }
    if ( ! is_email( $email ) ) {
        wp_send_json_error( [ 'message' => 'Please provide a valid email address.' ] );
    }

    // Send email to admin
    $admin_email = get_option( 'admin_email' );
    $headers     = [
        'Content-Type: text/html; charset=UTF-8',
        "Reply-To: {$name} <{$email}>",
    ];
    $body = "<p><strong>Name:</strong> {$name}</p>
             <p><strong>Email:</strong> {$email}</p>
             <p><strong>Subject:</strong> {$subject}</p>
             <p><strong>Message:</strong><br>" . nl2br( esc_html( $message ) ) . "</p>";

    wp_mail( $admin_email, '[LuxWatch] ' . $subject, $body, $headers );

    wp_send_json_success( [ 'message' => 'Message sent successfully.' ] );
}
add_action( 'wp_ajax_lw_contact_form',        'lw_ajax_contact_form' );
add_action( 'wp_ajax_nopriv_lw_contact_form', 'lw_ajax_contact_form' );
