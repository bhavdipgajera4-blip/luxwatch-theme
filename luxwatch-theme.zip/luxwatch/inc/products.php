<?php
/**
 * LuxWatch – Sample Products Data
 * All products are defined here and accessed theme-wide via lw_get_products().
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Returns all sample watch products.
 * Each product has: id, name, brand, category, price, ref, rating, badge,
 *                   description, image (Unsplash URL), specs array.
 */
function lw_get_products() {
    return [
        [
            'id'          => 1,
            'name'        => 'Royal Perpetual',
            'brand'       => 'Chronos Elite',
            'category'    => 'dress',
            'price'       => 12500,
            'ref'         => 'CE-2024-RP',
            'rating'      => 5,
            'badge'       => 'Bestseller',
            'description' => 'The Royal Perpetual embodies the pinnacle of horological craft. Powered by a self-winding caliber with perpetual calendar complication, this masterpiece unites classic elegance with extraordinary precision. The 42mm rose gold case houses a mesmerising blue lacquer dial adorned with hand-applied indices.',
            'image'       => 'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'Automatic, Cal. 3235',
                'Case'       => '42mm Rose Gold',
                'Dial'       => 'Blue Lacquer',
                'Water Resistance' => '100m / 330ft',
                'Power Reserve'    => '70 Hours',
                'Crystal'    => 'Sapphire, AR-coated',
            ],
        ],
        [
            'id'          => 2,
            'name'        => 'Submariner Noir',
            'brand'       => 'DeepSea Watch Co.',
            'category'    => 'diver',
            'price'       => 9800,
            'ref'         => 'DS-2024-SN',
            'rating'      => 5,
            'badge'       => 'New Arrival',
            'description' => 'Born from the depths, the Submariner Noir is a technical tour de force. Rated to 300 metres, this professional diver\'s watch features a unidirectional rotating bezel with Cerachrom insert, glidelock clasp, and a striking black PVD case. Luminescent hands ensure readability in any condition.',
            'image'       => 'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'Automatic, Cal. 3235',
                'Case'       => '40mm Black PVD Steel',
                'Dial'       => 'Black with LumiNova',
                'Water Resistance' => '300m / 1000ft',
                'Power Reserve'    => '70 Hours',
                'Crystal'    => 'Sapphire, AR-coated',
            ],
        ],
        [
            'id'          => 3,
            'name'        => 'Grand Tourbillon',
            'brand'       => 'Maison Horloge',
            'category'    => 'dress',
            'price'       => 48000,
            'ref'         => 'MH-2024-GT',
            'rating'      => 5,
            'badge'       => 'Limited',
            'description' => 'A symphony of mechanical artistry, the Grand Tourbillon represents Maison Horloge\'s ultimate expression of watchmaking mastery. The in-house flying tourbillon at 6 o\'clock rotates every 60 seconds, combating the effects of gravity with effortless elegance. Limited to 50 pieces worldwide.',
            'image'       => 'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'Manual Wind, Tourbillon',
                'Case'       => '44mm Platinum',
                'Dial'       => 'Skeleton, Hand-engraved',
                'Water Resistance' => '30m / 100ft',
                'Power Reserve'    => '55 Hours',
                'Crystal'    => 'Sapphire Front & Back',
            ],
        ],
        [
            'id'          => 4,
            'name'        => 'Pilot Heritage GMT',
            'brand'       => 'AeroTempus',
            'category'    => 'pilot',
            'price'       => 6750,
            'ref'         => 'AT-2024-PH',
            'rating'      => 4,
            'badge'       => '',
            'description' => 'Inspired by the golden age of aviation, the Pilot Heritage GMT tracks two time zones simultaneously. The large, legible dial with hour markers and the distinctive crown at 3 o\'clock make this an icon for the modern traveller. An anti-reflective domed sapphire crystal provides superior clarity.',
            'image'       => 'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'Automatic, GMT Cal.',
                'Case'       => '44mm Steel',
                'Dial'       => 'Black, Arabic Numerals',
                'Water Resistance' => '50m / 165ft',
                'Power Reserve'    => '68 Hours',
                'Crystal'    => 'Domed Sapphire',
            ],
        ],
        [
            'id'          => 5,
            'name'        => 'Moonphase Céleste',
            'brand'       => 'Astral Horlogerie',
            'category'    => 'dress',
            'price'       => 18900,
            'ref'         => 'AH-2024-MC',
            'rating'      => 5,
            'badge'       => 'Featured',
            'description' => 'The Moonphase Céleste is a celestial poem on the wrist. Its enamel dial depicts a deep-blue nocturnal sky, with a precise moonphase complication accurate to one day in 122 years. A ladies\' masterpiece in 36mm white gold, set with 48 brilliant-cut diamonds on the bezel.',
            'image'       => 'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'Automatic, Cal. 2460 QGL',
                'Case'       => '36mm White Gold',
                'Dial'       => 'Blue Grand Feu Enamel',
                'Water Resistance' => '30m / 100ft',
                'Power Reserve'    => '40 Hours',
                'Crystal'    => 'Sapphire, AR-coated',
            ],
        ],
        [
            'id'          => 6,
            'name'        => 'Chrono Velocity',
            'brand'       => 'Velocitas Watch Co.',
            'category'    => 'sport',
            'price'       => 7200,
            'ref'         => 'VW-2024-CV',
            'rating'      => 4,
            'badge'       => 'Popular',
            'description' => 'The Chrono Velocity is the ultimate sports chronograph for those who demand precision. A column-wheel flyback mechanism allows instant reset of the chronograph — critical for motorsport timing. The bi-compax layout on the sunburst grey dial is both functional and aesthetically refined.',
            'image'       => 'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'Manual, Column-Wheel Flyback',
                'Case'       => '41mm Steel',
                'Dial'       => 'Sunburst Grey',
                'Water Resistance' => '100m / 330ft',
                'Power Reserve'    => '65 Hours',
                'Crystal'    => 'Sapphire',
            ],
        ],
        [
            'id'          => 7,
            'name'        => 'Aquanaut Titanium',
            'brand'       => 'Pacific Depth',
            'category'    => 'diver',
            'price'       => 15400,
            'ref'         => 'PD-2024-AT',
            'rating'      => 5,
            'badge'       => '',
            'description' => 'The Aquanaut Titanium fuses advanced materials science with aquatic performance. A grade-5 titanium case makes it 40% lighter than steel whilst retaining exceptional durability. The integrated composite-textile strap is water-resistant, and the 600-metre depth rating opens the world\'s oceans to exploration.',
            'image'       => 'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'Automatic, Cal. 324 S C',
                'Case'       => '42mm Grade-5 Titanium',
                'Dial'       => 'Black Embossed',
                'Water Resistance' => '600m / 2000ft',
                'Power Reserve'    => '45 Hours',
                'Crystal'    => 'Sapphire, AR-coated',
            ],
        ],
        [
            'id'          => 8,
            'name'        => 'Reverso Classique',
            'brand'       => 'La Reverso',
            'category'    => 'dress',
            'price'       => 22000,
            'ref'         => 'LR-2024-RC',
            'rating'      => 5,
            'badge'       => 'Iconic',
            'description' => 'An icon since its creation for polo players in the 1930s, the Reverso Classique\'s swivelling case is a feat of Art Deco design. The caseback transforms into a canvas for hand-engraved personal motifs. Inside beats a hand-wound movement finished with Côtes de Genève and bevelled bridges.',
            'image'       => 'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'Manual Wind, Cal. 822',
                'Case'       => '29x47mm Yellow Gold',
                'Dial'       => 'Cream Opaline',
                'Water Resistance' => '30m / 100ft',
                'Power Reserve'    => '42 Hours',
                'Crystal'    => 'Sapphire',
            ],
        ],
        [
            'id'          => 9,
            'name'        => 'Endurance Pro',
            'brand'       => 'Breitfield',
            'category'    => 'sport',
            'price'       => 5490,
            'ref'         => 'BF-2024-EP',
            'rating'      => 4,
            'badge'       => 'New',
            'description' => 'Engineered for extreme conditions, the Endurance Pro pushes the boundaries of sports watchmaking. Its ultra-lightweight Breitlight case material is 3.3 times lighter than titanium and extremely hard. The SuperQuartz movement is 10× more precise than a standard quartz movement.',
            'image'       => 'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'SuperQuartz B82',
                'Case'       => '44mm Breitlight',
                'Dial'       => 'Orange Rubber-Effect',
                'Water Resistance' => '100m / 330ft',
                'Power Reserve'    => 'Battery 4 Years',
                'Crystal'    => 'Sapphire',
            ],
        ],
        [
            'id'          => 10,
            'name'        => 'Constellation Oro',
            'brand'       => 'Stella Orologi',
            'category'    => 'dress',
            'price'       => 31500,
            'ref'         => 'SO-2024-CO',
            'rating'      => 5,
            'badge'       => 'Exclusive',
            'description' => 'The Constellation Oro is a statement of understated opulence. The 18-carat Sedna gold case catches light from every angle, while the meteorite dial — unique in the world — ensures no two pieces are identical. A bracelet integrating the seamless "Ladybird" clasp completes this exceptional timepiece.',
            'image'       => 'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
            'images'      => [
                'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80',
                'https://images.unsplash.com/photo-1548171915-e79a380a2a4b?w=800&q=80',
                'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
                'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80',
            ],
            'specs' => [
                'Movement'   => 'Automatic, Co-Axial Master',
                'Case'       => '41mm Sedna Gold',
                'Dial'       => 'Meteorite',
                'Water Resistance' => '50m / 165ft',
                'Power Reserve'    => '60 Hours',
                'Crystal'    => 'Sapphire, AR-coated',
            ],
        ],
    ];
}

/**
 * Get a single product by ID.
 */
function lw_get_product( $id ) {
    foreach ( lw_get_products() as $p ) {
        if ( (int) $p['id'] === (int) $id ) return $p;
    }
    return null;
}

/**
 * Format price as currency string.
 */
function lw_format_price( $price ) {
    return '$' . number_format( $price, 0, '.', ',' );
}

/**
 * Render star rating HTML.
 */
function lw_stars( $rating ) {
    $html = '<div class="product-rating">';
    for ( $i = 1; $i <= 5; $i++ ) {
        $class = $i <= $rating ? 'star' : 'star empty';
        $html .= '<span class="' . $class . '">★</span>';
    }
    $html .= '</div>';
    return $html;
}
