<?php
/**
 * LuxWatch – index.php
 * Fallback template. WordPress requires this file.
 */
get_header();
?>

<div style="min-height:80vh;background:var(--black);padding-top:120px;padding-bottom:6rem;">
    <div class="container">
        <div class="text-center" style="margin-bottom:4rem;" data-animate>
            <span class="section-label">Latest News</span>
            <h1 class="section-title">From the Atelier</h1>
            <div class="gold-divider"></div>
        </div>

        <?php if ( have_posts() ) : ?>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;max-width:1100px;margin:0 auto;">
                <?php while ( have_posts() ) : the_post(); ?>
                <article style="background:var(--black-soft);border:1px solid rgba(255,255,255,0.06);overflow:hidden;">
                    <?php if ( has_post_thumbnail() ) : ?>
                        <div style="aspect-ratio:16/9;overflow:hidden;">
                            <?php the_post_thumbnail( 'medium', [ 'style' => 'width:100%;height:100%;object-fit:cover;' ] ); ?>
                        </div>
                    <?php endif; ?>
                    <div style="padding:1.75rem;">
                        <div style="font-size:0.6rem;letter-spacing:0.2em;text-transform:uppercase;color:var(--gold);margin-bottom:0.75rem;">
                            <?php echo get_the_date(); ?>
                        </div>
                        <h2 style="font-family:var(--font-serif);font-size:1.25rem;font-weight:400;margin-bottom:1rem;">
                            <a href="<?php the_permalink(); ?>" style="color:var(--white);"><?php the_title(); ?></a>
                        </h2>
                        <div style="font-size:0.8rem;color:var(--grey-light);line-height:1.75;margin-bottom:1.5rem;">
                            <?php the_excerpt(); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="btn btn-outline" style="padding:0.6rem 1.4rem;font-size:0.62rem;">Read More</a>
                    </div>
                </article>
                <?php endwhile; ?>
            </div>
            <div style="margin-top:3rem;text-align:center;"><?php the_posts_navigation(); ?></div>
        <?php else : ?>
            <div style="text-align:center;padding:4rem 0;">
                <p style="color:var(--grey);margin-bottom:2rem;">No posts found.</p>
                <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-gold">Explore Watches</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
