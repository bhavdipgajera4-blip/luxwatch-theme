<?php
/**
 * Template Name: About Us
 * Brand story, mission, values, team.
 */
get_header();
?>

<!-- ======================================================
     ABOUT HERO
     ====================================================== -->
<section class="about-hero">
    <div class="container">
        <div style="max-width:680px;" data-animate>
            <span class="section-label">Our Heritage</span>
            <h1 style="margin-bottom:1.5rem;">
                Where Time<br>Becomes <em>Art</em>
            </h1>
            <div class="gold-divider left"></div>
            <p style="font-size:1rem;color:var(--grey-light);line-height:1.9;max-width:520px;margin-top:1.5rem;">
                Since 1887, LuxWatch has been dedicated to the highest ideals of Swiss horology — crafting timepieces that transcend mere function to become enduring works of art passed down through generations.
            </p>
        </div>
    </div>
</section>

<!-- ======================================================
     MISSION
     ====================================================== -->
<section class="about-mission">
    <div class="container">
        <div class="grid-2" style="align-items:center;gap:6rem;">
            <div data-animate>
                <span class="section-label">Our Mission</span>
                <h2 class="section-title">Crafted to Outlast Generations</h2>
                <div class="gold-divider left"></div>
                <p style="margin:1.5rem 0;font-size:0.9rem;line-height:1.9;color:var(--grey-light);">
                    At LuxWatch, we believe that a truly great watch is not merely measured — it is felt. Every component, from the tiniest jewel in the movement to the clasp of the bracelet, is conceived to bring joy, precision, and beauty for a lifetime.
                </p>
                <p style="font-size:0.9rem;line-height:1.9;color:var(--grey-light);margin-bottom:2.5rem;">
                    Our ateliers in Geneva employ 47 master craftsmen, each specialised in a single discipline — from dial painting to movement regulation — ensuring that every watch bearing our name is the finest expression of its kind.
                </p>
                <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-gold">Explore Collection</a>
            </div>

            <div data-animate data-delay="150">
                <div style="position:relative;">
                    <img
                        src="https://images.unsplash.com/photo-1539874754764-5a96559165b0?w=900&q=80"
                        alt="Watchmaking atelier"
                        style="width:100%;aspect-ratio:4/5;object-fit:cover;filter:brightness(0.75);"
                    >
                    <div style="position:absolute;bottom:2rem;left:-2rem;background:var(--black-soft);border:1px solid rgba(201,168,76,0.3);padding:1.5rem 2rem;">
                        <div style="font-family:var(--font-serif);font-size:2.5rem;color:var(--gold);">47</div>
                        <div style="font-size:0.65rem;letter-spacing:0.2em;text-transform:uppercase;color:var(--grey);">Master Craftsmen</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ======================================================
     BRAND VALUES
     ====================================================== -->
<section style="background:var(--black);padding:7rem 0;">
    <div class="container">
        <div class="text-center" style="margin-bottom:1rem;" data-animate>
            <span class="section-label">What We Stand For</span>
            <h2 class="section-title">Our Founding Principles</h2>
            <div class="gold-divider"></div>
        </div>

        <div class="values-grid">
            <?php
            $values = [
                [ 'num' => '01', 'title' => 'Precision',     'desc' => 'Every movement is tested for a minimum of 15 days and regulated to within ±2 seconds per day — a standard surpassing COSC chronometric certification.' ],
                [ 'num' => '02', 'title' => 'Integrity',     'desc' => 'We use only ethically sourced precious metals and conflict-free gemstones. Our supply chain is audited annually by independent third parties.' ],
                [ 'num' => '03', 'title' => 'Artistry',      'desc' => 'Each dial is a hand-finished canvas. Our guillocheurs, engravers and enamellists trained for decades to achieve levels of craft that cannot be replicated by machine.' ],
                [ 'num' => '04', 'title' => 'Heritage',      'desc' => 'Our archives hold over 4,000 historical calibres. We draw on 137 years of institutional knowledge to inform every new creation — tradition informing innovation.' ],
                [ 'num' => '05', 'title' => 'Service',       'desc' => 'Every LuxWatch comes with a personalised service passport and a dedicated client advisor who remains your contact for the lifetime of the watch.' ],
                [ 'num' => '06', 'title' => 'Sustainability', 'desc' => 'Our manufacture runs on 100% renewable energy. By 2030, we commit to full carbon neutrality across our entire value chain.' ],
            ];
            foreach ( $values as $i => $v ) :
            ?>
            <div class="value-card" data-animate data-delay="<?php echo ($i % 3) * 80; ?>">
                <div class="value-number"><?php echo esc_html( $v['num'] ); ?></div>
                <h3 class="value-title"><?php echo esc_html( $v['title'] ); ?></h3>
                <p class="value-desc"><?php echo esc_html( $v['desc'] ); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ======================================================
     TIMELINE
     ====================================================== -->
<section style="background:var(--black-soft);padding:7rem 0;border-top:1px solid rgba(255,255,255,0.04);">
    <div class="container">
        <div class="text-center" style="margin-bottom:4rem;" data-animate>
            <span class="section-label">Our Journey</span>
            <h2 class="section-title">137 Years of History</h2>
            <div class="gold-divider"></div>
        </div>

        <div style="position:relative;max-width:800px;margin:0 auto;">
            <!-- Vertical line -->
            <div style="position:absolute;left:50%;top:0;bottom:0;width:1px;background:linear-gradient(to bottom,transparent,rgba(201,168,76,0.3),rgba(201,168,76,0.3),transparent);transform:translateX(-50%);"></div>

            <?php
            $timeline = [
                [ 'year' => '1887', 'event' => 'Founded by Henri-Claude Lecourt in a small atelier on the Rue de la Paix, Geneva. First calibre produces accurate to 5 seconds per day.' ],
                [ 'year' => '1924', 'event' => 'Introduction of the iconic "Perpetuel" case design, still referenced in our collections today. First self-winding movement.' ],
                [ 'year' => '1955', 'event' => 'The Submariner Noir becomes the first dive watch rated to 200 metres. Worn by the British Royal Navy.' ],
                [ 'year' => '1978', 'event' => 'Third generation family ownership. Launch of the Grand Complications line with perpetual calendar and minute repeater.' ],
                [ 'year' => '2003', 'event' => 'Opening of the new manufacture in Le Brassus. Full vertical integration achieved — from raw metal to finished watch.' ],
                [ 'year' => '2024', 'event' => 'Launch of our digital boutique, bringing the LuxWatch experience to collectors worldwide. New tourbillon calibre unveiled.' ],
            ];
            foreach ( $timeline as $i => $t ) :
                $is_right = $i % 2 === 0;
            ?>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:3rem;margin-bottom:3rem;align-items:center;" data-animate data-delay="<?php echo $i * 80; ?>">
                <?php if ( $is_right ) : ?>
                    <div style="text-align:right;padding-right:2rem;">
                        <div style="font-family:var(--font-serif);font-size:2rem;color:var(--gold);margin-bottom:0.5rem;"><?php echo esc_html($t['year']); ?></div>
                        <p style="font-size:0.82rem;line-height:1.75;color:var(--grey-light);"><?php echo esc_html($t['event']); ?></p>
                    </div>
                    <div></div>
                <?php else : ?>
                    <div></div>
                    <div style="padding-left:2rem;">
                        <div style="font-family:var(--font-serif);font-size:2rem;color:var(--gold);margin-bottom:0.5rem;"><?php echo esc_html($t['year']); ?></div>
                        <p style="font-size:0.82rem;line-height:1.75;color:var(--grey-light);"><?php echo esc_html($t['event']); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ======================================================
     TEAM
     ====================================================== -->
<section class="team-section">
    <div class="container">
        <div class="text-center" style="margin-bottom:1rem;" data-animate>
            <span class="section-label">The People Behind the Craft</span>
            <h2 class="section-title">Our Leadership</h2>
            <div class="gold-divider"></div>
        </div>

        <div class="team-grid">
            <?php
            $team = [
                [ 'name' => 'Édouard Lecourt', 'role' => 'Master Horologist & CEO',  'img' => 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80' ],
                [ 'name' => 'Isabelle Charpentier', 'role' => 'Creative Director',   'img' => 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&q=80' ],
                [ 'name' => 'Dr. Marcus Vogt',  'role' => 'Head of Complications',  'img' => 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=600&q=80' ],
            ];
            foreach ( $team as $i => $member ) :
            ?>
            <div class="team-card" data-animate data-delay="<?php echo $i * 100; ?>">
                <div class="team-img-wrap">
                    <img src="<?php echo esc_url( $member['img'] ); ?>" alt="<?php echo esc_attr( $member['name'] ); ?>" loading="lazy">
                </div>
                <div class="team-name"><?php echo esc_html( $member['name'] ); ?></div>
                <div class="team-role"><?php echo esc_html( $member['role'] ); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA -->
<section style="background:linear-gradient(135deg,#0f0f0f,#1a1400,#0f0f0f);padding:5rem 0;border-top:1px solid rgba(201,168,76,0.15);">
    <div class="container text-center" data-animate>
        <span class="section-label">Begin Your Journey</span>
        <h2 class="section-title">Discover Your Perfect Timepiece</h2>
        <div class="gold-divider"></div>
        <div style="display:flex;gap:1rem;justify-content:center;margin-top:2rem;flex-wrap:wrap;">
            <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-gold">Shop Collection</a>
            <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="btn btn-outline">Contact Us</a>
        </div>
    </div>
</section>

<?php get_footer(); ?>
