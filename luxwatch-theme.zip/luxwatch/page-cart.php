<?php
/**
 * Template Name: Cart
 * Displays cart contents with ability to remove items and proceed to checkout.
 */
get_header();
$cart  = lw_get_cart();
$total = lw_cart_total();
?>

<!-- Page Hero -->
<section class="page-hero">
    <div class="container">
        <span class="section-label">Your Selection</span>
        <h1>Shopping Cart</h1>
        <div class="gold-divider"></div>
    </div>
</section>

<div style="background:var(--black);">
    <div class="container">
        <div class="cart-wrap">

            <!-- ===== Cart Items ===== -->
            <div class="cart-items-section">
                <?php if ( empty( $cart ) ) : ?>
                    <!-- Empty State -->
                    <div class="cart-empty-state">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" width="64" height="64" style="color:var(--grey-dark);margin:0 auto 1.5rem;">
                            <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>
                            <line x1="3" y1="6" x2="21" y2="6"/>
                            <path d="M16 10a4 4 0 01-8 0"/>
                        </svg>
                        <h3>Your cart is empty</h3>
                        <p style="margin-bottom:2.5rem;">Discover our collection of exceptional timepieces and add one to your cart.</p>
                        <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-gold">Explore Collection</a>
                    </div>

                <?php else : ?>
                    <table class="cart-table">
                        <thead>
                            <tr>
                                <th style="width:50%;">Timepiece</th>
                                <th>Price</th>
                                <th>Qty</th>
                                <th>Subtotal</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $cart as $item ) : ?>
                            <tr class="cart-row">
                                <td>
                                    <div class="cart-product-cell">
                                        <img
                                            src="<?php echo esc_url( $item['image'] ); ?>"
                                            alt="<?php echo esc_attr( $item['name'] ); ?>"
                                            class="cart-img"
                                            loading="lazy"
                                        >
                                        <div>
                                            <div class="cart-item-brand"><?php echo esc_html( $item['brand'] ); ?></div>
                                            <div class="cart-item-name"><?php echo esc_html( $item['name'] ); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="cart-item-price"><?php echo lw_format_price( $item['price'] ); ?></span>
                                </td>
                                <td>
                                    <span style="font-size:0.9rem;color:var(--white);"><?php echo intval( $item['qty'] ); ?></span>
                                </td>
                                <td>
                                    <span class="cart-item-subtotal"><?php echo lw_format_price( $item['price'] * $item['qty'] ); ?></span>
                                </td>
                                <td>
                                    <button
                                        class="cart-remove-btn"
                                        data-id="<?php echo esc_attr( $item['id'] ); ?>"
                                        aria-label="Remove <?php echo esc_attr( $item['name'] ); ?>"
                                    >
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="18" height="18">
                                            <polyline points="3 6 5 6 21 6"/>
                                            <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                                            <path d="M10 11v6"/><path d="M14 11v6"/>
                                            <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
                                        </svg>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:2.5rem;flex-wrap:wrap;gap:1rem;">
                        <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-dark">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
                                <line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>
                            </svg>
                            Continue Shopping
                        </a>
                        <span style="font-size:0.75rem;color:var(--grey);letter-spacing:0.1em;">
                            <?php echo lw_cart_count(); ?> item<?php echo lw_cart_count() !== 1 ? 's' : ''; ?> in your cart
                        </span>
                    </div>
                <?php endif; ?>
            </div><!-- .cart-items-section -->

            <!-- ===== Cart Summary ===== -->
            <?php if ( ! empty( $cart ) ) : ?>
            <aside class="cart-summary">
                <h3>Order Summary</h3>

                <div class="summary-row">
                    <span class="label">Subtotal</span>
                    <span class="value"><?php echo lw_format_price( $total ); ?></span>
                </div>
                <div class="summary-row">
                    <span class="label">Shipping</span>
                    <span class="value" style="color:var(--gold);">Complimentary</span>
                </div>
                <div class="summary-row">
                    <span class="label">Insurance</span>
                    <span class="value" style="color:var(--gold);">Included</span>
                </div>
                <div class="summary-row">
                    <span class="label">Certificate of Authenticity</span>
                    <span class="value" style="color:var(--gold);">Included</span>
                </div>

                <div class="summary-total-row">
                    <span class="summary-total-label">Total</span>
                    <span class="summary-total-value"><?php echo lw_format_price( $total ); ?></span>
                </div>

                <a href="<?php echo esc_url( home_url( '/checkout' ) ); ?>" class="btn btn-gold checkout-btn">
                    Proceed to Checkout
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
                        <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
                    </svg>
                </a>

                <!-- Accepted payment icons (decorative) -->
                <div style="margin-top:2rem;padding-top:1.5rem;border-top:1px solid rgba(255,255,255,0.07);">
                    <p style="font-size:0.65rem;letter-spacing:0.15em;text-transform:uppercase;color:var(--grey);margin-bottom:1rem;text-align:center;">Secure Payment</p>
                    <div style="display:flex;gap:0.75rem;justify-content:center;flex-wrap:wrap;">
                        <?php $cards = ['VISA','MC','AMEX','PayPal']; foreach($cards as $c): ?>
                            <span style="background:var(--charcoal);border:1px solid rgba(255,255,255,0.08);padding:0.3rem 0.75rem;font-size:0.6rem;color:var(--grey-light);font-weight:600;letter-spacing:0.05em;"><?php echo $c; ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </aside>
            <?php endif; ?>

        </div><!-- .cart-wrap -->
    </div><!-- .container -->
</div>

<?php get_footer(); ?>
