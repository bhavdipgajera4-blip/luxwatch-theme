<?php
/**
 * Template Name: Checkout
 * Billing form + order summary. Places order via AJAX.
 */
get_header();
$cart  = lw_get_cart();
$total = lw_cart_total();

// If cart is empty, redirect to products
if ( empty( $cart ) && ! headers_sent() ) {
    wp_redirect( home_url( '/products' ) );
    exit;
}
?>

<!-- Page Hero -->
<section class="page-hero">
    <div class="container">
        <span class="section-label">Final Step</span>
        <h1>Checkout</h1>
        <div class="gold-divider"></div>
    </div>
</section>

<div style="background:var(--black);">
    <div class="container">
        <div class="checkout-wrap">

            <!-- ===== Checkout Form ===== -->
            <div class="checkout-form-section">
                <h3>Delivery & Contact Information</h3>

                <form id="checkout-form" novalidate>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="first_name">First Name *</label>
                            <input type="text" id="first_name" name="first_name" class="form-input" placeholder="James" required>
                            <span class="form-error"></span>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="last_name">Last Name *</label>
                            <input type="text" id="last_name" name="last_name" class="form-input" placeholder="Harrington" required>
                            <span class="form-error"></span>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="email">Email Address *</label>
                            <input type="email" id="email" name="email" class="form-input" placeholder="james@example.com" required>
                            <span class="form-error"></span>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" class="form-input" placeholder="+1 (555) 000-0000">
                            <span class="form-error"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="address">Street Address *</label>
                        <input type="text" id="address" name="address" class="form-input" placeholder="123 Mayfair Avenue" required>
                        <span class="form-error"></span>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="city">City *</label>
                            <input type="text" id="city" name="city" class="form-input" placeholder="London" required>
                            <span class="form-error"></span>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="zip">ZIP / Postal Code *</label>
                            <input type="text" id="zip" name="zip" class="form-input" placeholder="W1K 2HP" required>
                            <span class="form-error"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="country">Country *</label>
                        <select id="country" name="country" class="form-select" required>
                            <option value="">Select Country</option>
                            <option>United Kingdom</option>
                            <option>United States</option>
                            <option>France</option>
                            <option>Germany</option>
                            <option>Switzerland</option>
                            <option>Italy</option>
                            <option>Spain</option>
                            <option>Australia</option>
                            <option>Canada</option>
                            <option>Japan</option>
                            <option>UAE</option>
                            <option>India</option>
                            <option>Singapore</option>
                            <option>Other</option>
                        </select>
                        <span class="form-error"></span>
                    </div>

                    <!-- Payment (placeholder — informational) -->
                    <div style="margin-top:2.5rem;padding:2rem;background:var(--black-soft);border:1px solid rgba(255,255,255,0.07);">
                        <h4 style="font-family:var(--font-sans);font-size:0.65rem;letter-spacing:0.25em;text-transform:uppercase;color:var(--gold);margin-bottom:1.25rem;">Payment Method</h4>
                        <div style="display:flex;gap:1rem;flex-wrap:wrap;">
                            <?php $methods = ['Credit Card','Bank Transfer','PayPal','Cryptocurrency']; foreach($methods as $i=>$m): ?>
                                <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.8rem;color:var(--grey-light);">
                                    <input type="radio" name="payment_method" value="<?php echo esc_attr($m); ?>" <?php echo $i===0?'checked':''; ?> style="accent-color:var(--gold);">
                                    <?php echo esc_html($m); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <p style="font-size:0.72rem;color:var(--grey);margin-top:1rem;line-height:1.7;">
                            This is a demo theme. No real payment will be processed. Click "Place Order" to receive a sample order confirmation.
                        </p>
                    </div>

                </form>
            </div>

            <!-- ===== Order Summary ===== -->
            <aside class="order-summary-section">
                <h3>Your Order</h3>

                <!-- Items -->
                <?php foreach ( $cart as $item ) : ?>
                <div class="checkout-item">
                    <img
                        src="<?php echo esc_url( $item['image'] ); ?>"
                        alt="<?php echo esc_attr( $item['name'] ); ?>"
                        loading="lazy"
                    >
                    <div class="checkout-item-info">
                        <div class="checkout-item-name"><?php echo esc_html( $item['name'] ); ?></div>
                        <div class="checkout-item-qty">Qty: <?php echo intval( $item['qty'] ); ?></div>
                    </div>
                    <div class="checkout-item-price"><?php echo lw_format_price( $item['price'] * $item['qty'] ); ?></div>
                </div>
                <?php endforeach; ?>

                <!-- Totals -->
                <div style="margin-top:1.5rem;">
                    <div class="summary-row">
                        <span class="label" style="font-size:0.78rem;color:var(--grey-light);">Subtotal</span>
                        <span class="value" style="font-size:0.85rem;"><?php echo lw_format_price( $total ); ?></span>
                    </div>
                    <div class="summary-row">
                        <span class="label" style="font-size:0.78rem;color:var(--grey-light);">Shipping</span>
                        <span style="color:var(--gold);font-size:0.82rem;">Complimentary</span>
                    </div>
                    <div class="summary-row">
                        <span class="label" style="font-size:0.78rem;color:var(--grey-light);">Warranty</span>
                        <span style="color:var(--gold);font-size:0.82rem;">5 Years Included</span>
                    </div>

                    <div class="summary-total-row">
                        <span class="summary-total-label">Total</span>
                        <span class="summary-total-value"><?php echo lw_format_price( $total ); ?></span>
                    </div>
                </div>

                <button class="btn btn-gold place-order-btn" type="button">
                    Place Order
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
                        <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                        <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                </button>

                <p style="font-size:0.7rem;color:var(--grey);text-align:center;margin-top:1.25rem;line-height:1.7;">
                    By placing your order you agree to our <a href="#" style="color:var(--gold);">Terms &amp; Conditions</a>. Your data is protected in accordance with our <a href="#" style="color:var(--gold);">Privacy Policy</a>.
                </p>
            </aside>

        </div><!-- .checkout-wrap -->
    </div><!-- .container -->
</div>

<!-- ======================================================
     ORDER SUCCESS MODAL
     ====================================================== -->
<div class="success-overlay" role="dialog" aria-modal="true" aria-label="Order Confirmation">
    <div class="success-modal">
        <div class="success-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <path d="M20 6L9 17l-5-5"/>
            </svg>
        </div>

        <h2>Order Confirmed!</h2>
        <p>
            Your timepiece is being prepared with the utmost care by our Geneva atelier.
            A confirmation has been dispatched to your email address.
        </p>

        <div class="success-order-num">
            <span>Order Reference</span>
            <strong class="order-number-display">LW-XXXXXXXX</strong>
        </div>

        <p style="font-size:0.8rem;margin-bottom:2rem;">
            Estimated delivery: <strong style="color:var(--gold);">7–14 business days</strong> via insured express courier with white-glove delivery.
        </p>

        <button class="btn btn-gold success-close-btn" style="width:100%;justify-content:center;">
            Return to Homepage
        </button>
    </div>
</div>

<?php get_footer(); ?>
