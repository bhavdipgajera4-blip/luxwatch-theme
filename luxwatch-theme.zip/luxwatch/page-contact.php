<?php
/**
 * Template Name: Contact
 * Contact form with AJAX submission and validation.
 */
get_header();
?>

<!-- Page Hero -->
<section class="page-hero">
    <div class="container">
        <span class="section-label">Get in Touch</span>
        <h1>Contact Us</h1>
        <div class="gold-divider"></div>
        <p style="max-width:500px;margin:0 auto;">
            Whether you seek a private consultation, have questions about our collection, or wish to arrange a bespoke commission — our team is at your service.
        </p>
    </div>
</section>

<div style="background:var(--black);">
    <div class="container">
        <div class="contact-wrap">

            <!-- ===== Contact Information ===== -->
            <div class="contact-info" data-animate>
                <span class="section-label">Reach Us</span>
                <h2>We'd Love to<br>Hear From You</h2>
                <div class="gold-divider left"></div>
                <p style="margin-bottom:3rem;line-height:1.9;">
                    Our client advisors are available Monday through Saturday to assist with any enquiry. For urgent requests regarding a recent order, please call directly.
                </p>

                <div class="contact-detail">
                    <div class="contact-detail-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/>
                            <circle cx="12" cy="10" r="3"/>
                        </svg>
                    </div>
                    <div>
                        <div class="contact-detail-title">Flagship Boutique</div>
                        <div class="contact-detail-text">12 Rue de la Paix<br>Geneva 1204, Switzerland</div>
                    </div>
                </div>

                <div class="contact-detail">
                    <div class="contact-detail-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013 8.77a19.79 19.79 0 01-3.07-8.67A2 2 0 011.92 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"/>
                        </svg>
                    </div>
                    <div>
                        <div class="contact-detail-title">Telephone</div>
                        <div class="contact-detail-text">+41 22 000 0000<br>Mon–Sat, 9:00–19:00 CET</div>
                    </div>
                </div>

                <div class="contact-detail">
                    <div class="contact-detail-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                            <polyline points="22,6 12,13 2,6"/>
                        </svg>
                    </div>
                    <div>
                        <div class="contact-detail-title">Email</div>
                        <div class="contact-detail-text">boutique@luxwatch.com<br>service@luxwatch.com</div>
                    </div>
                </div>

                <div class="contact-detail">
                    <div class="contact-detail-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <circle cx="12" cy="12" r="10"/>
                            <polyline points="12 6 12 12 16 14"/>
                        </svg>
                    </div>
                    <div>
                        <div class="contact-detail-title">Opening Hours</div>
                        <div class="contact-detail-text">
                            Monday – Friday: 9:00am – 7:00pm<br>
                            Saturday: 10:00am – 5:00pm<br>
                            Sunday: Closed
                        </div>
                    </div>
                </div>

                <!-- Map placeholder -->
                <div style="margin-top:2.5rem;background:var(--black-soft);border:1px solid rgba(255,255,255,0.06);height:200px;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;">
                    <div style="position:absolute;inset:0;background:linear-gradient(135deg,rgba(201,168,76,0.05),transparent);"></div>
                    <div style="text-align:center;position:relative;z-index:1;">
                        <svg viewBox="0 0 24 24" fill="none" stroke="var(--gold)" stroke-width="1" width="32" height="32" style="margin:0 auto 0.75rem;">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/>
                            <circle cx="12" cy="10" r="3"/>
                        </svg>
                        <p style="font-size:0.7rem;letter-spacing:0.15em;color:var(--grey);">12 Rue de la Paix, Geneva</p>
                    </div>
                </div>
            </div>

            <!-- ===== Contact Form ===== -->
            <div class="contact-form-card" data-animate data-delay="150">
                <h2 class="contact-form-title">Send a Message</h2>

                <!-- Success state (hidden by default) -->
                <div class="contact-success">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="48" height="48">
                        <path d="M22 11.08V12a10 10 0 11-5.93-9.14" stroke="var(--gold)"/>
                        <polyline points="22 4 12 14.01 9 11.01" stroke="var(--gold)"/>
                    </svg>
                    <h4>Message Sent!</h4>
                    <p>Thank you for reaching out. A member of our team will respond within 24 hours.</p>
                </div>

                <form id="contact-form" novalidate>
                    <?php wp_nonce_field( 'lw_nonce', '_wpnonce' ); ?>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="contact_name">Your Name *</label>
                            <input type="text" id="contact_name" name="contact_name" class="form-input" placeholder="James Harrington" required>
                            <span class="form-error"></span>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="contact_email">Email Address *</label>
                            <input type="email" id="contact_email" name="contact_email" class="form-input" placeholder="james@example.com" required>
                            <span class="form-error"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="contact_subject">Subject</label>
                        <select id="contact_subject" name="contact_subject" class="form-select">
                            <option value="General Enquiry">General Enquiry</option>
                            <option value="Product Information">Product Information</option>
                            <option value="Order Status">Order Status</option>
                            <option value="After-Sales Service">After-Sales Service</option>
                            <option value="Bespoke Commission">Bespoke Commission</option>
                            <option value="Press & Partnerships">Press &amp; Partnerships</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="contact_message">Your Message *</label>
                        <textarea id="contact_message" name="contact_message" class="form-textarea" placeholder="Please describe how we may assist you…" rows="6" required></textarea>
                        <span class="form-error"></span>
                    </div>

                    <div class="form-group" style="display:flex;align-items:flex-start;gap:0.75rem;">
                        <input type="checkbox" id="privacy_agree" name="privacy_agree" style="margin-top:3px;accent-color:var(--gold);flex-shrink:0;">
                        <label for="privacy_agree" style="font-size:0.75rem;color:var(--grey);line-height:1.6;cursor:pointer;">
                            I have read and agree to the <a href="#" style="color:var(--gold);">Privacy Policy</a>. I consent to LuxWatch storing my submitted information to respond to my enquiry.
                        </label>
                    </div>

                    <button type="submit" class="btn btn-gold" style="width:100%;justify-content:center;margin-top:0.5rem;">
                        Send Message
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
                            <line x1="22" y1="2" x2="11" y2="13"/>
                            <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                        </svg>
                    </button>
                </form>
            </div>

        </div><!-- .contact-wrap -->
    </div><!-- .container -->
</div>

<?php get_footer(); ?>
