<?php
/**
 * Template Name: Single Product
 * Displays a single watch with gallery, specs, and add-to-cart.
 * Access via: /product/?pid=1
 */

// Resolve product from query string
$pid     = absint( $_GET['pid'] ?? 0 );
$product = lw_get_product( $pid );

// Fallback — show first product if none found
if ( ! $product ) {
    $all_products = lw_get_products();
    $product      = $all_products[0];
}

// Update the page <title> via filter
add_filter( 'document_title_parts', function( $parts ) use ( $product ) {
    $parts['title'] = esc_html( $product['name'] ) . ' – LuxWatch';
    return $parts;
} );

get_header();
?>

<!-- Breadcrumbs -->
<div style="background:var(--black-soft);border-bottom:1px solid rgba(255,255,255,0.05);padding:1rem 0;margin-top:72px;">
    <div class="container">
        <nav style="font-size:0.7rem;color:var(--grey);letter-spacing:0.1em;display:flex;gap:0.5rem;align-items:center;">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:var(--grey);">Home</a>
            <span>›</span>
            <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" style="color:var(--grey);">Collection</a>
            <span>›</span>
            <span style="color:var(--gold);"><?php echo esc_html( $product['name'] ); ?></span>
        </nav>
    </div>
</div>

<!-- Single Product Layout -->
<section style="background:var(--black);padding-bottom:6rem;">
    <div class="container">
        <div class="single-product-wrap">

            <!-- === Gallery === -->
            <div class="product-gallery" data-animate>
                <div class="main-image-wrap">
                    <img
                        id="main-product-img"
                        src="<?php echo esc_url( $product['images'][0] ); ?>"
                        alt="<?php echo esc_attr( $product['name'] ); ?>"
                    >
                </div>
                <div class="thumbnail-row">
                    <?php foreach ( $product['images'] as $idx => $img ) : ?>
                        <div class="thumb-item <?php echo $idx === 0 ? 'active' : ''; ?>">
                            <img src="<?php echo esc_url( $img ); ?>" alt="View <?php echo $idx + 1; ?>" loading="lazy">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- === Info Panel === -->
            <div class="product-detail-info" data-animate data-delay="120">

                <?php if ( $product['badge'] ) : ?>
                    <div style="margin-bottom:1rem;">
                        <span class="product-badge" style="position:static;display:inline-block;"><?php echo esc_html( $product['badge'] ); ?></span>
                    </div>
                <?php endif; ?>

                <div class="product-detail-brand"><?php echo esc_html( $product['brand'] ); ?></div>
                <h1 class="product-detail-title"><?php echo esc_html( $product['name'] ); ?></h1>
                <div class="product-detail-ref">Ref. <?php echo esc_html( $product['ref'] ); ?></div>

                <?php echo lw_stars( $product['rating'] ); ?>

                <!-- Price -->
                <div class="product-detail-price" style="margin-top:1.5rem;">
                    <div class="price-main"><?php echo lw_format_price( $product['price'] ); ?></div>
                    <div class="price-note">Incl. VAT · Free Worldwide Shipping</div>
                </div>

                <!-- Specifications -->
                <div class="product-spec-list">
                    <?php foreach ( $product['specs'] as $label => $value ) : ?>
                        <div class="spec-item">
                            <div class="spec-label"><?php echo esc_html( $label ); ?></div>
                            <div class="spec-value"><?php echo esc_html( $value ); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Quantity -->
                <div class="qty-row">
                    <span class="qty-label">Quantity</span>
                    <div class="qty-control">
                        <button class="qty-btn qty-dec" aria-label="Decrease">−</button>
                        <input type="number" class="qty-input" value="1" min="1" max="10" aria-label="Quantity">
                        <button class="qty-btn qty-inc" aria-label="Increase">+</button>
                    </div>
                </div>

                <!-- Add to Cart -->
                <button
                    class="btn btn-gold add-to-cart-btn"
                    data-id="<?php echo esc_attr( $product['id'] ); ?>"
                    data-name="<?php echo esc_attr( $product['name'] ); ?>"
                >
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                        <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>
                        <line x1="3" y1="6" x2="21" y2="6"/>
                        <path d="M16 10a4 4 0 01-8 0"/>
                    </svg>
                    Add to Cart
                </button>

                <a href="<?php echo esc_url( home_url( '/checkout' ) ); ?>" class="btn btn-outline" style="width:100%;justify-content:center;">
                    Buy Now
                </a>

                <!-- Description -->
                <div class="product-description">
                    <h4>About This Timepiece</h4>
                    <p><?php echo esc_html( $product['description'] ); ?></p>
                </div>

                <!-- Trust badges -->
                <div style="display:flex;gap:2rem;margin-top:2.5rem;padding-top:2rem;border-top:1px solid rgba(255,255,255,0.07);flex-wrap:wrap;">
                    <div style="display:flex;align-items:center;gap:0.6rem;">
                        <svg viewBox="0 0 24 24" fill="none" stroke="var(--gold)" stroke-width="1.5" width="18" height="18"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        <span style="font-size:0.7rem;color:var(--grey-light);">Certificate Included</span>
                    </div>
                    <div style="display:flex;align-items:center;gap:0.6rem;">
                        <svg viewBox="0 0 24 24" fill="none" stroke="var(--gold)" stroke-width="1.5" width="18" height="18"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <span style="font-size:0.7rem;color:var(--grey-light);">Free International Shipping</span>
                    </div>
                    <div style="display:flex;align-items:center;gap:0.6rem;">
                        <svg viewBox="0 0 24 24" fill="none" stroke="var(--gold)" stroke-width="1.5" width="18" height="18"><circle cx="12" cy="12" r="10"/><polyline points="12 8 12 12 14 14"/></svg>
                        <span style="font-size:0.7rem;color:var(--grey-light);">5-Year Warranty</span>
                    </div>
                </div>

            </div><!-- .product-detail-info -->
        </div>
    </div><!-- .container -->
</section>

<!-- Related Products -->
<section style="background:var(--black-soft);padding:5rem 0;">
    <div class="container">
        <div class="section-header" style="margin-bottom:3rem;" data-animate>
            <div>
                <span class="section-label">Also of Interest</span>
                <h2 class="section-title">Related Timepieces</h2>
            </div>
            <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-outline">View All</a>
        </div>

        <div class="products-grid" style="grid-template-columns:repeat(3,1fr);">
            <?php
            $all  = lw_get_products();
            $related = array_filter( $all, fn($p) => $p['id'] !== $product['id'] );
            foreach ( array_slice( array_values($related), 0, 3 ) as $i => $p ) :
            ?>
            <div class="product-card" data-animate data-delay="<?php echo $i * 80; ?>">
                <?php if ( $p['badge'] ) : ?>
                    <span class="product-badge"><?php echo esc_html( $p['badge'] ); ?></span>
                <?php endif; ?>
                <div class="product-img-wrap">
                    <img src="<?php echo esc_url( $p['image'] ); ?>" alt="<?php echo esc_attr( $p['name'] ); ?>" class="product-img" loading="lazy">
                    <button class="product-quick-add" data-id="<?php echo esc_attr( $p['id'] ); ?>" data-name="<?php echo esc_attr( $p['name'] ); ?>">Add to Cart</button>
                </div>
                <div class="product-info">
                    <div class="product-brand"><?php echo esc_html( $p['brand'] ); ?></div>
                    <h3 class="product-name">
                        <a href="<?php echo esc_url( home_url( '/product/?pid=' . $p['id'] ) ); ?>"><?php echo esc_html( $p['name'] ); ?></a>
                    </h3>
                    <div class="product-footer">
                        <span class="product-price"><span class="currency">$</span><?php echo number_format( $p['price'] ); ?></span>
                        <?php echo lw_stars( $p['rating'] ); ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>
