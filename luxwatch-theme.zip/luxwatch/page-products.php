<?php
/**
 * Template Name: Products
 * Full product catalogue with category filter.
 */
get_header();
$products   = lw_get_products();
$categories = [ 'all' => 'All Watches', 'dress' => 'Dress', 'diver' => 'Diver', 'pilot' => 'Pilot', 'sport' => 'Sport' ];
?>

<!-- Page Hero -->
<section class="page-hero">
    <div class="container" data-animate>
        <span class="section-label">Our Collection</span>
        <h1>Fine Timepieces</h1>
        <div class="gold-divider"></div>
        <p style="max-width:500px;margin:0 auto;">
            A curated selection of the world's finest watches — each piece handpicked for its exceptional craftsmanship and enduring elegance.
        </p>
    </div>
</section>

<!-- Filter Bar -->
<div class="filter-bar">
    <div class="container">
        <div class="filter-inner">
            <?php foreach ( $categories as $slug => $label ) : ?>
                <button class="filter-btn <?php echo $slug === 'all' ? 'active' : ''; ?>" data-filter="<?php echo esc_attr( $slug ); ?>">
                    <?php echo esc_html( $label ); ?>
                </button>
            <?php endforeach; ?>

            <span class="products-count">Showing <?php echo count( $products ); ?> timepieces</span>
        </div>
    </div>
</div>

<!-- Products Grid -->
<section style="background:var(--black);padding:4rem 0 7rem;">
    <div class="container">
        <div class="products-grid" id="products-grid">
            <?php foreach ( $products as $i => $p ) : ?>
            <div class="product-card" data-category="<?php echo esc_attr( $p['category'] ); ?>" data-animate data-delay="<?php echo ( $i % 3 ) * 80; ?>">

                <?php if ( $p['badge'] ) : ?>
                    <span class="product-badge"><?php echo esc_html( $p['badge'] ); ?></span>
                <?php endif; ?>

                <div class="product-img-wrap">
                    <img
                        src="<?php echo esc_url( $p['image'] ); ?>"
                        alt="<?php echo esc_attr( $p['name'] ); ?>"
                        class="product-img"
                        loading="lazy"
                    >
                    <button
                        class="product-quick-add"
                        data-id="<?php echo esc_attr( $p['id'] ); ?>"
                        data-name="<?php echo esc_attr( $p['name'] ); ?>"
                    >Add to Cart</button>
                </div>

                <div class="product-info">
                    <div class="product-brand"><?php echo esc_html( $p['brand'] ); ?></div>
                    <h3 class="product-name">
                        <a href="<?php echo esc_url( home_url( '/product/?pid=' . $p['id'] ) ); ?>">
                            <?php echo esc_html( $p['name'] ); ?>
                        </a>
                    </h3>
                    <p class="product-desc"><?php echo esc_html( substr( $p['description'], 0, 90 ) . '…' ); ?></p>
                    <div class="product-footer">
                        <span class="product-price">
                            <span class="currency">$</span><?php echo number_format( $p['price'] ); ?>
                        </span>
                        <?php echo lw_stars( $p['rating'] ); ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>
