<?php
/**
 * LuxWatch – page.php
 * Generic page template.
 */
get_header();
?>
<div style="min-height:80vh;background:var(--black);padding-top:120px;padding-bottom:6rem;">
    <div class="container" style="max-width:860px;">
        <?php while ( have_posts() ) : the_post(); ?>
            <div style="margin-bottom:3rem;" data-animate>
                <span class="section-label">LuxWatch</span>
                <h1 class="section-title"><?php the_title(); ?></h1>
                <div class="gold-divider left"></div>
            </div>
            <div style="font-size:0.92rem;color:var(--grey-light);line-height:1.9;" data-animate data-delay="100">
                <?php the_content(); ?>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php get_footer(); ?>
