<?php
/**
 * search.php – Search results page.
 */
get_header();
$search_query = get_search_query();
$products     = lw_get_products();

// Simple search through products
$results = array_filter( $products, function( $p ) use ( $search_query ) {
    $q = strtolower( $search_query );
    return strpos( strtolower( $p['name'] ), $q ) !== false
        || strpos( strtolower( $p['brand'] ), $q ) !== false
        || strpos( strtolower( $p['description'] ), $q ) !== false;
} );
?>

<!-- Page Hero -->
<section class="page-hero">
    <div class="container">
        <span class="section-label">Search Results</span>
        <h1>
            <?php if ( $search_query ) : ?>
                "<?php echo esc_html( $search_query ); ?>"
            <?php else : ?>
                All Results
            <?php endif; ?>
        </h1>
        <div class="gold-divider"></div>
        <p><?php echo count( $results ); ?> timepiece<?php echo count( $results ) !== 1 ? 's' : ''; ?> found</p>
    </div>
</section>

<section style="background:var(--black);padding:4rem 0 7rem;">
    <div class="container">
        <?php if ( ! empty( $results ) ) : ?>
            <div class="products-grid">
                <?php foreach ( array_values( $results ) as $i => $p ) : ?>
                <div class="product-card" data-animate data-delay="<?php echo ( $i % 3 ) * 80; ?>">
                    <?php if ( $p['badge'] ) : ?>
                        <span class="product-badge"><?php echo esc_html( $p['badge'] ); ?></span>
                    <?php endif; ?>
                    <div class="product-img-wrap">
                        <img src="<?php echo esc_url( $p['image'] ); ?>" alt="<?php echo esc_attr( $p['name'] ); ?>" class="product-img" loading="lazy">
                        <button class="product-quick-add" data-id="<?php echo esc_attr( $p['id'] ); ?>" data-name="<?php echo esc_attr( $p['name'] ); ?>">Add to Cart</button>
                    </div>
                    <div class="product-info">
                        <div class="product-brand"><?php echo esc_html( $p['brand'] ); ?></div>
                        <h3 class="product-name">
                            <a href="<?php echo esc_url( home_url( '/product/?pid=' . $p['id'] ) ); ?>"><?php echo esc_html( $p['name'] ); ?></a>
                        </h3>
                        <div class="product-footer">
                            <span class="product-price"><span class="currency">$</span><?php echo number_format( $p['price'] ); ?></span>
                            <?php echo lw_stars( $p['rating'] ); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else : ?>
            <div class="cart-empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" width="56" height="56" style="color:var(--grey-dark);margin:0 auto 1.5rem;">
                    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
                <h3>No results found</h3>
                <p style="margin-bottom:2rem;">Try a different search term or browse our full collection.</p>
                <a href="<?php echo esc_url( home_url( '/products' ) ); ?>" class="btn btn-gold">Browse Collection</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>
