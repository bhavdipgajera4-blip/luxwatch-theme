<?php
/**
 * LuxWatch – single.php
 * Single post template.
 */
get_header();
?>
<div style="min-height:80vh;background:var(--black);padding-top:100px;padding-bottom:6rem;">
    <div class="container" style="max-width:820px;">
        <?php while ( have_posts() ) : the_post(); ?>
            <?php if ( has_post_thumbnail() ) : ?>
            <div style="margin-bottom:3rem;aspect-ratio:16/7;overflow:hidden;" data-animate>
                <?php the_post_thumbnail( 'large', [ 'style' => 'width:100%;height:100%;object-fit:cover;filter:brightness(0.8);' ] ); ?>
            </div>
            <?php endif; ?>
            <div data-animate>
                <div style="display:flex;align-items:center;gap:1.5rem;margin-bottom:1.5rem;">
                    <span style="font-size:0.6rem;letter-spacing:0.25em;text-transform:uppercase;color:var(--gold);"><?php echo get_the_date(); ?></span>
                    <span style="font-size:0.6rem;letter-spacing:0.25em;text-transform:uppercase;color:var(--grey);">By <?php the_author(); ?></span>
                </div>
                <h1 style="font-family:var(--font-serif);font-size:clamp(2rem,4vw,3rem);font-weight:300;margin-bottom:2rem;"><?php the_title(); ?></h1>
                <div style="width:60px;height:1px;background:linear-gradient(90deg,transparent,var(--gold),transparent);margin-bottom:2.5rem;"></div>
                <div style="font-size:0.92rem;color:var(--grey-light);line-height:2;"><?php the_content(); ?></div>
                <div style="margin-top:4rem;padding-top:2.5rem;border-top:1px solid rgba(255,255,255,0.07);display:flex;justify-content:space-between;gap:2rem;flex-wrap:wrap;">
                    <?php $prev = get_previous_post(); $next = get_next_post(); ?>
                    <?php if ( $prev ) : ?>
                        <a href="<?php echo esc_url( get_permalink( $prev ) ); ?>" style="display:flex;flex-direction:column;gap:0.4rem;max-width:48%;">
                            <span style="font-size:0.6rem;letter-spacing:0.2em;text-transform:uppercase;color:var(--gold);">← Previous</span>
                            <span style="font-size:0.85rem;color:var(--white);"><?php echo esc_html( get_the_title( $prev ) ); ?></span>
                        </a>
                    <?php endif; ?>
                    <?php if ( $next ) : ?>
                        <a href="<?php echo esc_url( get_permalink( $next ) ); ?>" style="display:flex;flex-direction:column;gap:0.4rem;text-align:right;max-width:48%;margin-left:auto;">
                            <span style="font-size:0.6rem;letter-spacing:0.2em;text-transform:uppercase;color:var(--gold);">Next →</span>
                            <span style="font-size:0.85rem;color:var(--white);"><?php echo esc_html( get_the_title( $next ) ); ?></span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php get_footer(); ?>
