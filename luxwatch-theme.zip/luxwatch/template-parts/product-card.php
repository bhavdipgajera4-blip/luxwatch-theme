<?php
/**
 * template-parts/product-card.php
 * Reusable product card partial.
 * Usage: get_template_part( 'template-parts/product-card', null, [ 'product' => $product ] );
 */

$product = $args['product'] ?? null;
if ( ! $product ) return;
?>

<div class="product-card" data-category="<?php echo esc_attr( $product['category'] ); ?>">

    <?php if ( ! empty( $product['badge'] ) ) : ?>
        <span class="product-badge"><?php echo esc_html( $product['badge'] ); ?></span>
    <?php endif; ?>

    <div class="product-img-wrap">
        <img
            src="<?php echo esc_url( $product['image'] ); ?>"
            alt="<?php echo esc_attr( $product['name'] ); ?>"
            class="product-img"
            loading="lazy"
        >
        <button
            class="product-quick-add"
            data-id="<?php echo esc_attr( $product['id'] ); ?>"
            data-name="<?php echo esc_attr( $product['name'] ); ?>"
        >Add to Cart</button>
    </div>

    <div class="product-info">
        <div class="product-brand"><?php echo esc_html( $product['brand'] ); ?></div>
        <h3 class="product-name">
            <a href="<?php echo esc_url( home_url( '/product/?pid=' . $product['id'] ) ); ?>">
                <?php echo esc_html( $product['name'] ); ?>
            </a>
        </h3>
        <p class="product-desc">
            <?php echo esc_html( substr( $product['description'], 0, 90 ) . '…' ); ?>
        </p>
        <div class="product-footer">
            <span class="product-price">
                <span class="currency">$</span><?php echo number_format( $product['price'] ); ?>
            </span>
            <?php echo lw_stars( $product['rating'] ); ?>
        </div>
    </div>
</div>
